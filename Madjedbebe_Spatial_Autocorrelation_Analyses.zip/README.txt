Madjedbebe spatial analysis package V4

What this package does
- Runs the corrected horizontal spatial patterning workflow on the Madjedbebe aggregated dataset
- Handles duplicate Square × Depth rows automatically by aggregating them
- Calculates:
  - global Moran's I by material and depth
  - local hotspot results by square, material, and depth
  - adjacent-depth hotspot persistence pairs
  - formal hotspot runs across consecutive 10 cm bins
  - run-length summaries
  - figures and summary text
  - cross-phase vertical hotspot sequence figure
  - all-depth local clustering panel figure

Files expected in the same folder
- run_hybrid_analysis_click_me.bat
- run_madjedbebe_spatial_analysis.py
- madjedbebe_final_aggregated_dataset.csv

How to run
1. Unzip this folder anywhere on your Windows computer.
2. Keep all files together in the same folder.
3. Double-click:
   run_hybrid_analysis_click_me.bat
4. If successful, the results folder will open automatically.

Outputs written to
- madjedbebe_spatial_outputs

Main output files
- global_moran_summary.csv
- local_all_results.csv
- local_hotspots_only.csv
- vertical_hotspot_persistence_pairs.csv
- vertical_hotspot_runs.csv
- run_length_summary.csv
- run_length_by_sector_summary.csv
- cross_phase_boundary_summary.csv
- phase_diagnostic_materials_by_phase.png
- significant_global_clustering_maps.png
- vertical_hotspot_run_lengths.png
- multibin_runs_by_sector.png
- cross_phase_vertical_sequences.png
- all_depth_local_clustering_panels.png
- analysis_summary.txt

What changed from earlier versions
- package writes to a single output folder only (madjedbebe_spatial_outputs)
- duplicate Square × Depth rows are auto-aggregated
- true run-length analysis is included
- cross-phase sequence and all-depth local clustering figures are generated automatically
- cross-phase figure matches the approved final style
- significant global clustering maps now use the same grid orientation as the other figures
- run-length outputs are integrated with the slope-adjusted phase assignments already present in the input dataset

Input requirements
The input file must contain one row per Square x Depth 10cm or a file that can be safely aggregated to that structure.
Minimum required fields:
- Square
- Depth 10cm
- Phase
- Total_artefacts

If Row, Column, or Sector are missing, the script derives them from Square.

Default materials analysed
- Quartz
- Crystal Quartz
- Quartzite
- Fine Quartzite
- Silcrete
- Chert
- Volcanic
- Oenpelli Dolerite
- Gerowie Tuff

Optional command-line use
py -3 run_madjedbebe_spatial_analysis.py --input madjedbebe_final_aggregated_dataset.csv --output-dir madjedbebe_spatial_outputs

Optional settings
- --materials "Quartz,Silcrete,Chert"
- --min-count 10
- --n-perm 999
- --alpha 0.05

If something goes wrong
- the window will stay open
- run_log.txt will be created in the same folder
- send the contents of run_log.txt back for diagnosis

Python packages required
py -3 -m pip install numpy pandas matplotlib openpyxl
