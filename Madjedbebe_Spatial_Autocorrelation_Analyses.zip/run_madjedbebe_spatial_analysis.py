#!/usr/bin/env python3
from __future__ import annotations

import argparse
from pathlib import Path
import math
from typing import List, Dict, Tuple

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt


DEFAULT_MATERIALS = [
    "Quartz",
    "Crystal Quartz",
    "Quartzite",
    "Fine Quartzite",
    "Silcrete",
    "Chert",
    "Volcanic",
    "Oenpelli Dolerite",
    "Gerowie Tuff",
]

ROW_ORDER = ["E", "D", "C", "B"]
STRUCTURE_ROWS_TOPDOWN = ["B", "C", "D", "E"]
STRUCTURE_VALID_COLS = {"B": [1, 2, 3, 4, 5, 6], "C": [1, 2, 3, 4, 5, 6], "D": [1, 2, 3, 4], "E": [1, 2, 3, 4]}
ALL_COLS = [1, 2, 3, 4, 5, 6]

LOCAL_FIGURE_COLORS = {
    "Quartzite": "#1b9e77",
    "Silcrete": "#d95f02",
    "Quartz": "#7570b3",
    "Fine Quartzite": "#66a61e",
    "Chert": "#e7298a",
    "Volcanic": "#e6ab02",
    "Oenpelli Dolerite": "#a6761d",
    "Gerowie Tuff": "#1f78b4",
    "Crystal Quartz": "#e41a1c",
}

LOCAL_LABEL_MAP = {
    "Quartzite": "Quartzite",
    "Silcrete": "Silcrete",
    "Quartz": "Quartz",
    "Fine Quartzite": "Fine\nQuartzite",
    "Chert": "Chert",
    "Volcanic": "Volcanic",
    "Oenpelli Dolerite": "Oenpelli\nDolerite",
    "Gerowie Tuff": "Gerowie\nTuff",
    "Crystal Quartz": "Crystal\nQuartz",
}

SQUARE_AVAILABILITY = {
    "B1": (1.6, 2.8), "B2": (0.1, 3.5), "B3": (0.1, 3.5), "B4": (0.1, 2.9), "B5": (0.1, 3.0), "B6": (0.1, 3.1),
    "C1": (0.1, 2.8), "C2": (0.1, 2.7), "C3": (0.1, 2.7), "C4": (0.1, 2.9), "C5": (0.1, 3.1), "C6": (0.1, 3.1),
    "D1": (0.8, 2.8), "D2": (0.1, 2.8), "D3": (0.1, 2.5), "D4": (0.1, 1.4),
    "E1": (0.1, 1.5), "E2": (0.1, 2.5), "E3": (0.1, 1.5), "E4": (0.1, 1.5),
}


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(
        description="Madjedbebe horizontal spatial patterning and run-length analysis"
    )
    p.add_argument("--input", default="madjedbebe_final_aggregated_dataset.csv",
                   help="Input CSV/XLSX file.")
    p.add_argument("--output-dir", default="madjedbebe_spatial_outputs",
                   help="Directory for outputs.")
    p.add_argument("--materials", default=",".join(DEFAULT_MATERIALS),
                   help="Comma-separated material columns to analyse.")
    p.add_argument("--min-count", type=int, default=5,
                   help="Minimum total count per material per depth interval.")
    p.add_argument("--n-perm", type=int, default=499,
                   help="Permutation count for Moran tests.")
    p.add_argument("--alpha", type=float, default=0.05,
                   help="Significance threshold.")
    return p.parse_args()


def load_input(path: Path) -> pd.DataFrame:
    if not path.exists():
        raise FileNotFoundError(f"Input file not found: {path}")
    if path.suffix.lower() == ".csv":
        return pd.read_csv(path)
    if path.suffix.lower() in {".xlsx", ".xls"}:
        return pd.read_excel(path)
    raise ValueError("Input must be CSV or XLSX/XLS")


def validate_and_prepare(df: pd.DataFrame) -> pd.DataFrame:
    required = {"Square", "Depth 10cm", "Phase", "Total_artefacts"}
    missing = required - set(df.columns)
    if missing:
        raise ValueError(f"Missing required columns: {sorted(missing)}")

    out = df.copy()
    out = out[out["Square"].notna()].copy()

    if "Row" not in out.columns:
        out["Row"] = out["Square"].astype(str).str.extract(r"([A-Z])")
    if "Column" not in out.columns:
        out["Column"] = out["Square"].astype(str).str.extract(r"(\d+)")
    out["Column"] = out["Column"].astype(float).astype(int)
    if "Sector" not in out.columns:
        out["Sector"] = np.where(out["Column"] <= 3, "back", "front")

    out["Depth 10cm"] = out["Depth 10cm"].astype(float)
    out["Phase"] = out["Phase"].astype(float)

    # Auto-aggregate duplicate Square x Depth rows safely
    dup_n = int(out.duplicated(subset=["Square", "Depth 10cm"]).sum())
    if dup_n:
        print(f"Detected {dup_n} duplicate Square x Depth rows. Auto-aggregating duplicates.")
        group_cols = ["Square", "Depth 10cm"]
        meta_cols = ["Row", "Column", "Sector", "Phase"]
        value_cols = [c for c in out.columns if c not in group_cols + meta_cols + ["Total_artefacts"]]
        agg_dict = {c: "sum" for c in value_cols}
        for c in meta_cols:
            agg_dict[c] = "first"
        out = out.groupby(group_cols, as_index=False).agg(agg_dict)
        out["Total_artefacts"] = out[value_cols].sum(axis=1)

    # Final uniqueness check
    dup_n2 = int(out.duplicated(subset=["Square", "Depth 10cm"]).sum())
    if dup_n2:
        raise ValueError(f"Duplicate Square x Depth rows remain after aggregation ({dup_n2}).")

    return out


def build_adjacency(squares: List[str], rows: List[str], cols: List[int]) -> np.ndarray:
    coords = list(zip(rows, cols))
    idx = {sq: i for i, sq in enumerate(squares)}
    coord_to_sq = {c: s for c, s in zip(coords, squares)}

    row_order = [r for r in ROW_ORDER if r in set(rows)]
    for r in sorted(set(rows)):
        if r not in row_order:
            row_order.append(r)
    row_pos = {r: i for i, r in enumerate(row_order)}

    W = np.zeros((len(squares), len(squares)), dtype=float)
    for sq, r, c in zip(squares, rows, cols):
        neighbors = []
        if (r, c - 1) in coord_to_sq:
            neighbors.append(coord_to_sq[(r, c - 1)])
        if (r, c + 1) in coord_to_sq:
            neighbors.append(coord_to_sq[(r, c + 1)])
        rp = row_pos[r]
        if rp > 0:
            rr = row_order[rp - 1]
            if (rr, c) in coord_to_sq:
                neighbors.append(coord_to_sq[(rr, c)])
        if rp < len(row_order) - 1:
            rr = row_order[rp + 1]
            if (rr, c) in coord_to_sq:
                neighbors.append(coord_to_sq[(rr, c)])
        i = idx[sq]
        for nsq in neighbors:
            W[i, idx[nsq]] = 1.0
    return W


def morans_i(x: np.ndarray, W: np.ndarray) -> float:
    x = np.asarray(x, dtype=float)
    if np.allclose(np.nanvar(x), 0.0):
        return np.nan
    xm = np.nanmean(x)
    z = x - xm
    den = np.nansum(z ** 2)
    if den == 0 or np.isnan(den):
        return np.nan
    s0 = W.sum()
    if s0 == 0:
        return np.nan
    num = z @ W @ z
    return (len(x) / s0) * (num / den)


def local_moran_values(x: np.ndarray, W: np.ndarray) -> np.ndarray:
    x = np.asarray(x, dtype=float)
    z = x - x.mean()
    m2 = np.sum(z**2) / len(x)
    if m2 == 0:
        return np.full(len(x), np.nan)
    return (z / m2) * (W @ z)


def global_perm_test(x: np.ndarray, W: np.ndarray, n_perm: int, seed: int) -> tuple[float, float]:
    rng = np.random.default_rng(seed)
    obs = morans_i(x, W)
    if np.isnan(obs):
        return np.nan, np.nan
    sims = np.empty(n_perm, dtype=float)
    for i in range(n_perm):
        sims[i] = morans_i(rng.permutation(x), W)
    p = (np.sum(np.abs(sims) >= abs(obs)) + 1) / (n_perm + 1)
    return obs, p


def local_perm_test(x: np.ndarray, W: np.ndarray, n_perm: int, seed: int):
    rng = np.random.default_rng(seed)
    obs = local_moran_values(x, W)
    if np.isnan(obs).all():
        return obs, np.full(len(x), np.nan), np.array(["none"] * len(x), dtype=object)

    z = x - x.mean()
    local_lag = W @ z
    quad = np.array(["none"] * len(x), dtype=object)
    quad[(z > 0) & (local_lag > 0)] = "HH"
    quad[(z < 0) & (local_lag < 0)] = "LL"
    quad[(z > 0) & (local_lag < 0)] = "HL"
    quad[(z < 0) & (local_lag > 0)] = "LH"

    sims = np.empty((n_perm, len(x)), dtype=float)
    for i in range(n_perm):
        sims[i] = local_moran_values(rng.permutation(x), W)
    p = (np.sum(np.abs(sims) >= np.abs(obs), axis=0) + 1) / (n_perm + 1)
    return obs, p, quad


def _draw_site_grid(ax, depth: float) -> None:
    open_color = "white"
    closed_color = "#d9d9d9"
    for i, row in enumerate(STRUCTURE_ROWS_TOPDOWN):
        for col in ALL_COLS:
            square = f"{row}{col}"
            x, y = col - 0.5, i - 0.5
            if col not in STRUCTURE_VALID_COLS[row]:
                ax.add_patch(plt.Rectangle((x, y), 1, 1, facecolor=closed_color, edgecolor="none"))
                continue
            start, end = SQUARE_AVAILABILITY.get(square, (999, -999))
            is_open = start <= depth <= end
            face = open_color if is_open else closed_color
            edge = "black" if is_open else "none"
            ax.add_patch(plt.Rectangle((x, y), 1, 1, facecolor=face, edgecolor=edge, linewidth=0.5))
    ax.set_xlim(0.5, 6.5)
    ax.set_ylim(3.5, -0.5)
    ax.set_aspect("equal")
    ax.set_xticks(ALL_COLS)
    ax.set_xticklabels(ALL_COLS, fontsize=9)
    ax.set_yticks(range(len(STRUCTURE_ROWS_TOPDOWN)))
    ax.set_yticklabels(STRUCTURE_ROWS_TOPDOWN, fontsize=9)
    ax.tick_params(length=0)
    for spine in ax.spines.values():
        spine.set_visible(False)


def _draw_structural_heatmap_base(ax, fill_value: float = 0.0, cmap_name: str = "viridis"):
    matrix = []
    for row in STRUCTURE_ROWS_TOPDOWN:
        vals = []
        for col in ALL_COLS:
            vals.append(fill_value if col in STRUCTURE_VALID_COLS[row] else np.nan)
        matrix.append(vals)
    matrix = np.array(matrix, dtype=float)
    cmap = plt.cm.get_cmap(cmap_name).copy()
    cmap.set_bad(color="#d9d9d9")
    ax.imshow(matrix, cmap=cmap, vmin=0, vmax=1)
    ax.set_xticks(range(len(ALL_COLS)))
    ax.set_xticklabels(ALL_COLS, fontsize=9)
    ax.set_yticks(range(len(STRUCTURE_ROWS_TOPDOWN)))
    ax.set_yticklabels(STRUCTURE_ROWS_TOPDOWN, fontsize=9)
    ax.set_xlim(-0.5, len(ALL_COLS)-0.5)
    ax.set_ylim(len(STRUCTURE_ROWS_TOPDOWN)-0.5, -0.5)
    ax.set_aspect("equal")
    ax.tick_params(length=0)


def make_cross_phase_sequence_figure(runs_df: pd.DataFrame, outdir: Path) -> Path:
    cross = runs_df[runs_df["Crosses_phase_boundary"]].copy()
    if cross.empty:
        fig, ax = plt.subplots(figsize=(8, 3))
        ax.text(0.5, 0.5, "No cross-phase vertical hotspot sequences", ha="center", va="center")
        ax.axis("off")
        out = outdir / "cross_phase_vertical_sequences.png"
        fig.savefig(out, dpi=300, bbox_inches="tight")
        plt.close(fig)
        return out

    order = {"D1": 0, "C2": 1, "D3": 2, "B6": 3}
    cross["sort_key"] = cross["Square"].map(order).fillna(999)
    cross = cross.sort_values(["sort_key", "Square", "Material"])

    fig, axes = plt.subplots(1, len(cross), figsize=(13.5, 4.2), constrained_layout=True)
    if len(cross) == 1:
        axes = [axes]

    for ax, (_, r) in zip(axes, cross.iterrows()):
        _draw_structural_heatmap_base(ax, fill_value=0.0, cmap_name="viridis")
        i = STRUCTURE_ROWS_TOPDOWN.index(r["Row"])
        j = int(r["Column"]) - 1
        ax.add_patch(plt.Rectangle((j - 0.5, i - 0.5), 1, 1, facecolor="#377eb8", edgecolor="white", linewidth=2))
        ax.text(j, i, r["Square"], ha="center", va="center", color="white", fontsize=12, fontweight="bold")
        ax.set_title(str(r["Material"]), fontsize=13, pad=20)
        ax.text(0.5, 1.01,
                f"{float(r['Depth_start']):.1f}–{float(r['Depth_end']):.1f} m | Phase {int(r['Phase_start'])}→{int(r['Phase_end'])} | {int(r['Run_length_bins'])} depth units",
                transform=ax.transAxes, ha="center", va="bottom", fontsize=9)

    out = outdir / "cross_phase_vertical_sequences.png"
    fig.savefig(out, dpi=300, bbox_inches="tight")
    plt.close(fig)
    return out


def make_all_depth_local_clustering_figure(local_hotspots: pd.DataFrame, local_all: pd.DataFrame, outdir: Path) -> Path:
    depths = sorted(local_all["Depth_10cm"].unique())
    grouped = (
        local_hotspots[local_hotspots["Material"].isin(LOCAL_FIGURE_COLORS)]
        .groupby(["Depth_10cm", "Square", "Row", "Column"])["Material"]
        .agg(lambda x: sorted(set(x), key=lambda m: list(LOCAL_FIGURE_COLORS.keys()).index(m)))
        .reset_index()
    )

    ncols, nrows = 5, 6
    fig, axes = plt.subplots(nrows, ncols, figsize=(22, 24))
    axes = axes.flatten()

    for ax, depth in zip(axes, depths):
        panel = grouped[grouped["Depth_10cm"] == depth]
        _draw_site_grid(ax, float(depth))
        for _, r in panel.iterrows():
            square = r["Square"]
            start, end = SQUARE_AVAILABILITY.get(square, (999, -999))
            if not (start <= float(depth) <= end):
                continue
            i = ["B", "C", "D", "E"].index(r["Row"])
            x0, y0 = int(r["Column"]) - 0.5, i - 0.5
            mats = [m for m in r["Material"] if m in LOCAL_FIGURE_COLORS]
            if len(mats) == 1:
                ax.add_patch(plt.Rectangle((x0, y0), 1, 1, facecolor=LOCAL_FIGURE_COLORS[mats[0]], edgecolor="black", linewidth=0.5))
            elif len(mats) > 1:
                band = 1 / len(mats)
                for k, m in enumerate(mats):
                    ax.add_patch(plt.Rectangle((x0 + k * band, y0), band, 1, facecolor=LOCAL_FIGURE_COLORS[m], edgecolor="none"))
                ax.add_patch(plt.Rectangle((x0, y0), 1, 1, facecolor="none", edgecolor="black", linewidth=0.5))
        ax.set_title(f"{float(depth):.1f} m", fontsize=12, pad=6)

        for ax2 in axes[len(depths):]:
            ax2.axis("off")

    handles = [plt.matplotlib.patches.Patch(facecolor=LOCAL_FIGURE_COLORS[m], edgecolor="black", label=LOCAL_LABEL_MAP[m]) for m in LOCAL_FIGURE_COLORS]
    handles.append(plt.matplotlib.patches.Patch(facecolor="#d9d9d9", edgecolor="none", label="Not open"))
    fig.legend(handles=handles, loc="lower center", bbox_to_anchor=(0.5, 0.02), ncol=len(handles), frameon=False,
               fontsize=14, title="Raw material", title_fontsize=16, handlelength=2.0, handletextpad=0.5, columnspacing=1.5)
    plt.subplots_adjust(left=0.05, right=0.98, top=0.97, bottom=0.10, wspace=0.10, hspace=0.35)
    out = outdir / "all_depth_local_clustering_panels.png"
    fig.savefig(out, dpi=300, bbox_inches="tight")
    plt.close(fig)
    return out


def analyse(df: pd.DataFrame, materials: List[str], outdir: Path, min_count: int, n_perm: int, alpha: float) -> Dict[str, Path]:
    outdir.mkdir(parents=True, exist_ok=True)

    missing = [m for m in materials if m not in df.columns]
    if missing:
        raise ValueError(f"Missing material columns: {missing}")

    # Phase summary
    phase_means = df.groupby("Phase")[materials].sum()
    phase_props = phase_means.div(phase_means.sum(axis=1), axis=0).fillna(0)
    fig, ax = plt.subplots(figsize=(12, 6))
    for m in materials:
        ax.plot(phase_props.index, phase_props[m], marker="o", label=m)
    ax.set_xlabel("Phase")
    ax.set_ylabel("Proportion within phase")
    ax.set_title("Phase-diagnostic materials by phase")
    ax.legend(fontsize=8, ncol=3)
    ax.set_xticks(sorted(phase_props.index))
    fig.tight_layout()
    phase_fig = outdir / "phase_diagnostic_materials_by_phase.png"
    fig.savefig(phase_fig, dpi=300)
    plt.close(fig)

    global_rows = []
    local_rows = []

    for depth in sorted(df["Depth 10cm"].unique()):
        dsub = df[df["Depth 10cm"] == depth].copy().sort_values(["Row", "Column"])
        squares = dsub["Square"].tolist()
        rows = dsub["Row"].tolist()
        cols = dsub["Column"].tolist()
        W = build_adjacency(squares, rows, cols)
        if W.sum() == 0:
            continue

        totals = dsub["Total_artefacts"].replace(0, np.nan)

        for m_idx, mat in enumerate(materials):
            counts = dsub[mat].fillna(0).astype(float)
            total_count = float(counts.sum())
            if total_count < min_count:
                global_rows.append({
                    "Depth_10cm": depth,
                    "Material": mat,
                    "N_total": total_count,
                    "Moran_I": np.nan,
                    "p_value": np.nan,
                    "Significant": False,
                    "Analysed": False,
                })
                continue

            props = (counts / totals).fillna(0).to_numpy(dtype=float)

            I, p = global_perm_test(props, W, n_perm=n_perm, seed=1234 + m_idx + int(round(depth * 100)))
            global_rows.append({
                "Depth_10cm": depth,
                "Material": mat,
                "N_total": total_count,
                "Moran_I": I,
                "p_value": p,
                "Significant": bool(pd.notna(p) and p < alpha),
                "Analysed": True,
            })

            local_I, local_p, quad = local_perm_test(props, W, n_perm=n_perm, seed=4321 + m_idx + int(round(depth * 100)))
            mean_prop = float(np.mean(props))
            for sq, row, col, phase, sector, prop, cnt, li, lp, q in zip(
                dsub["Square"], dsub["Row"], dsub["Column"], dsub["Phase"], dsub["Sector"],
                props, counts, local_I, local_p, quad
            ):
                hotspot = bool(pd.notna(lp) and lp < alpha and q == "HH" and prop > mean_prop)
                local_rows.append({
                    "Square": sq,
                    "Row": row,
                    "Column": int(col),
                    "Sector": sector,
                    "Phase": float(phase),
                    "Depth_10cm": depth,
                    "Material": mat,
                    "Count": float(cnt),
                    "Proportion": float(prop),
                    "Local_I": float(li) if pd.notna(li) else np.nan,
                    "p_value": float(lp) if pd.notna(lp) else np.nan,
                    "Quadrant": q,
                    "Hotspot": hotspot,
                })

    global_df = pd.DataFrame(global_rows).sort_values(["Material", "Depth_10cm"])
    local_df = pd.DataFrame(local_rows).sort_values(["Material", "Square", "Depth_10cm"])
    hotspots = local_df[local_df["Hotspot"]].copy().sort_values(["Material", "Square", "Depth_10cm"])

    global_path = outdir / "global_moran_summary.csv"
    local_all_path = outdir / "local_all_results.csv"
    hotspots_path = outdir / "local_hotspots_only.csv"
    global_df.to_csv(global_path, index=False)
    local_df.to_csv(local_all_path, index=False)
    hotspots.to_csv(hotspots_path, index=False)

    # Adjacent pairs and formal runs
    pair_rows = []
    run_rows = []
    for (mat, sq), g in hotspots.groupby(["Material", "Square"]):
        g = g.sort_values("Depth_10cm").reset_index(drop=True)
        depths = g["Depth_10cm"].tolist()
        phases = g["Phase"].tolist()
        sector = g["Sector"].iloc[0]
        row = g["Row"].iloc[0]
        col = int(g["Column"].iloc[0])

        for i in range(len(depths) - 1):
            step = round(depths[i + 1] - depths[i], 1)
            if step == 0.1:
                pair_rows.append({
                    "Material": mat,
                    "Square": sq,
                    "Row": row,
                    "Column": col,
                    "Sector": sector,
                    "Depth_A": depths[i],
                    "Phase_A": phases[i],
                    "Depth_B": depths[i + 1],
                    "Phase_B": phases[i + 1],
                    "Same_phase": bool(phases[i] == phases[i + 1]),
                    "Crosses_phase_boundary": bool(phases[i] != phases[i + 1]),
                })

        if not depths:
            continue

        start = depths[0]
        prev = depths[0]
        start_phase = phases[0]
        prev_phase = phases[0]
        run_len = 1

        for i in range(1, len(depths)):
            step = round(depths[i] - prev, 1)
            if step == 0.1:
                run_len += 1
                prev = depths[i]
                prev_phase = phases[i]
            else:
                run_rows.append({
                    "Material": mat,
                    "Square": sq,
                    "Row": row,
                    "Column": col,
                    "Sector": sector,
                    "Depth_start": start,
                    "Phase_start": start_phase,
                    "Depth_end": prev,
                    "Phase_end": prev_phase,
                    "Run_length_bins": run_len,
                    "Vertical_span_m": round(prev - start, 1),
                    "Crosses_phase_boundary": bool(start_phase != prev_phase),
                })
                start = depths[i]
                prev = depths[i]
                start_phase = phases[i]
                prev_phase = phases[i]
                run_len = 1

        run_rows.append({
            "Material": mat,
            "Square": sq,
            "Row": row,
            "Column": col,
            "Sector": sector,
            "Depth_start": start,
            "Phase_start": start_phase,
            "Depth_end": prev,
            "Phase_end": prev_phase,
            "Run_length_bins": run_len,
            "Vertical_span_m": round(prev - start, 1),
            "Crosses_phase_boundary": bool(start_phase != prev_phase),
        })

    pairs_df = pd.DataFrame(pair_rows).sort_values(["Material", "Square", "Depth_A"])
    runs_df = pd.DataFrame(run_rows).sort_values(
        ["Run_length_bins", "Material", "Square", "Depth_start"],
        ascending=[False, True, True, True]
    )
    pairs_path = outdir / "vertical_hotspot_persistence_pairs.csv"
    runs_path = outdir / "vertical_hotspot_runs.csv"
    pairs_df.to_csv(pairs_path, index=False)
    runs_df.to_csv(runs_path, index=False)

    # Summary tables
    run_length_summary = (
        runs_df.groupby(["Run_length_bins", "Crosses_phase_boundary"])
        .size()
        .reset_index(name="N_runs")
        .sort_values(["Run_length_bins", "Crosses_phase_boundary"], ascending=[False, True])
    )
    run_length_summary_path = outdir / "run_length_summary.csv"
    run_length_summary.to_csv(run_length_summary_path, index=False)

    run_length_sector_summary = (
        runs_df.groupby(["Sector", "Run_length_bins", "Crosses_phase_boundary"])
        .size()
        .reset_index(name="N_runs")
        .sort_values(["Sector", "Run_length_bins"], ascending=[True, False])
    )
    run_length_sector_path = outdir / "run_length_by_sector_summary.csv"
    run_length_sector_summary.to_csv(run_length_sector_path, index=False)

    boundary_summary = runs_df[runs_df["Crosses_phase_boundary"]].copy()
    if len(boundary_summary):
        boundary_summary["Boundary"] = (
            boundary_summary["Phase_start"].astype(int).astype(str)
            + "→" +
            boundary_summary["Phase_end"].astype(int).astype(str)
        )
        boundary_summary = (
            boundary_summary.groupby(["Boundary", "Sector"])
            .size()
            .reset_index(name="N_runs")
            .sort_values("N_runs", ascending=False)
        )
    else:
        boundary_summary = pd.DataFrame(columns=["Boundary", "Sector", "N_runs"])
    boundary_summary_path = outdir / "cross_phase_boundary_summary.csv"
    boundary_summary.to_csv(boundary_summary_path, index=False)

    # Run-length figure
    run_len_only = runs_df.groupby("Run_length_bins").size().reset_index(name="N_runs").sort_values("Run_length_bins", ascending=False)
    if len(run_len_only):
        run_len_only["Percent"] = (run_len_only["N_runs"] / run_len_only["N_runs"].sum() * 100).round(1)
    else:
        run_len_only["Percent"] = []
    fig, ax = plt.subplots(figsize=(7, 4.5))
    ax.bar(run_len_only["Run_length_bins"].astype(str), run_len_only["N_runs"])
    ax.set_xlabel("Hotspot run length (10 cm bins)")
    ax.set_ylabel("Number of runs")
    ax.set_title("Vertical hotspot run lengths")
    for i, (_, r) in enumerate(run_len_only.iterrows()):
        ax.text(i, r["N_runs"] + 0.6, f"{int(r['N_runs'])}\n({r['Percent']:.1f}%)", ha="center", va="bottom", fontsize=9)
    fig.tight_layout()
    run_length_fig = outdir / "vertical_hotspot_run_lengths.png"
    fig.savefig(run_length_fig, dpi=300)
    plt.close(fig)

    # Multi-bin run figure by sector
    multi = runs_df[runs_df["Run_length_bins"] >= 2].copy()
    if len(multi):
        tab = multi.groupby(["Sector", "Crosses_phase_boundary"]).size().unstack(fill_value=0)
    else:
        tab = pd.DataFrame(index=["back", "front"], columns=[False, True]).fillna(0)
    fig, ax = plt.subplots(figsize=(6.5, 4.5))
    x = np.arange(len(tab.index))
    width = 0.35
    vals_same = tab.get(False, pd.Series([0]*len(tab.index), index=tab.index)).values
    vals_cross = tab.get(True, pd.Series([0]*len(tab.index), index=tab.index)).values
    ax.bar(x - width/2, vals_same, width, label="Within-phase")
    ax.bar(x + width/2, vals_cross, width, label="Cross-phase")
    ax.set_xticks(x, tab.index)
    ax.set_ylabel("Number of runs (>=2 bins)")
    ax.set_title("Multi-bin hotspot runs by sector")
    ax.legend()
    fig.tight_layout()
    multibin_fig = outdir / "multibin_runs_by_sector.png"
    fig.savefig(multibin_fig, dpi=300)
    plt.close(fig)

    # Significant global clustering map figure
    sig_global = global_df[(global_df["Analysed"]) & (global_df["Significant"])].copy()
    if len(sig_global) == 0:
        fig, ax = plt.subplots(figsize=(8, 4))
        ax.text(0.5, 0.5, "No significant global clustering intervals", ha="center", va="center")
        ax.axis("off")
        sig_fig = outdir / "significant_global_clustering_maps.png"
        fig.savefig(sig_fig, dpi=300, bbox_inches="tight")
        plt.close(fig)
    else:
        ncols = 4
        nrows = math.ceil(len(sig_global) / ncols)
        fig, axes = plt.subplots(nrows, ncols, figsize=(4*ncols, 3.5*nrows))
        axes = np.array(axes).reshape(nrows, ncols)
        for ax in axes.flat:
            ax.axis("off")

        for ax, (_, rec) in zip(axes.flat, sig_global.iterrows()):
            depth = rec["Depth_10cm"]
            mat = rec["Material"]
            sub = local_df[(local_df["Depth_10cm"] == depth) & (local_df["Material"] == mat)].copy()
            grid = np.full((len(STRUCTURE_ROWS_TOPDOWN), len(ALL_COLS)), np.nan)
            for row in STRUCTURE_ROWS_TOPDOWN:
                for col in ALL_COLS:
                    if col in STRUCTURE_VALID_COLS[row]:
                        grid[STRUCTURE_ROWS_TOPDOWN.index(row), col-1] = 0.0
            for _, rr in sub.iterrows():
                r_i = STRUCTURE_ROWS_TOPDOWN.index(rr["Row"])
                c_i = int(rr["Column"]) - 1
                if 0 <= c_i < 6 and rr["Column"] in STRUCTURE_VALID_COLS[rr["Row"]]:
                    grid[r_i, c_i] = rr["Proportion"]
            cmap = plt.cm.viridis.copy()
            cmap.set_bad(color="#d9d9d9")
            vmax = np.nanmax(grid) if np.isfinite(grid).any() else 1e-6
            ax.imshow(grid, vmin=0, vmax=vmax, cmap=cmap)
            hs = sub[sub["Hotspot"]]
            for _, rr in hs.iterrows():
                r_i = STRUCTURE_ROWS_TOPDOWN.index(rr["Row"])
                c_i = int(rr["Column"]) - 1
                ax.add_patch(plt.Rectangle((c_i - 0.5, r_i - 0.5), 1, 1, fill=False, edgecolor="red", linewidth=2))
                ax.text(c_i, r_i, rr["Square"], ha="center", va="center", fontsize=7, color="white")
            ax.set_title(f"{mat} @ {depth:.1f} m\nI={rec['Moran_I']:.3f}, p={rec['p_value']:.3f}", fontsize=9)
            ax.set_xticks(range(6), labels=[1, 2, 3, 4, 5, 6], fontsize=8)
            ax.set_yticks(range(len(STRUCTURE_ROWS_TOPDOWN)), labels=STRUCTURE_ROWS_TOPDOWN, fontsize=8)
        fig.tight_layout()
        sig_fig = outdir / "significant_global_clustering_maps.png"
        fig.savefig(sig_fig, dpi=300, bbox_inches="tight")
        plt.close(fig)

    # Additional figures
    cross_phase_fig = make_cross_phase_sequence_figure(runs_df, outdir)
    all_depth_local_fig = make_all_depth_local_clustering_figure(hotspots, local_df, outdir)

    # Summary text
    total_pairs = len(pairs_df)
    same_phase_pairs = int(pairs_df["Same_phase"].sum()) if total_pairs else 0
    cross_phase_pairs = int((~pairs_df["Same_phase"]).sum()) if total_pairs else 0
    total_runs = len(runs_df)
    one_bin = int((runs_df["Run_length_bins"] == 1).sum()) if total_runs else 0
    two_bin = int((runs_df["Run_length_bins"] == 2).sum()) if total_runs else 0
    three_bin = int((runs_df["Run_length_bins"] == 3).sum()) if total_runs else 0
    max_run = int(runs_df["Run_length_bins"].max()) if total_runs else 0
    multi_bin = int((runs_df["Run_length_bins"] >= 2).sum()) if total_runs else 0
    cross_phase_multi = int(((runs_df["Run_length_bins"] >= 2) & (runs_df["Crosses_phase_boundary"])).sum()) if total_runs else 0

    summary_text = "\n".join([
        "Corrected run-length analysis summary",
        "",
        f"Materials analysed: {', '.join(materials)}",
        f"Minimum count threshold: {min_count}",
        f"Permutation count: {n_perm}",
        "",
        f"Total hotspot cells: {len(hotspots)}",
        f"Significant global clustering intervals: {len(sig_global)}",
        f"Adjacent-depth same-square hotspot pairs: {total_pairs}",
        f"Pairs within same phase: {same_phase_pairs}",
        f"Pairs crossing phase boundary: {cross_phase_pairs}",
        "",
        f"Total hotspot runs: {total_runs}",
        f"1-bin runs: {one_bin}",
        f"2-bin runs: {two_bin}",
        f"3-bin runs: {three_bin}",
        f"Maximum run length (bins): {max_run}",
        "",
        "Boundary-integrated interpretation",
        "Phase assignments are taken directly from the input dataset, which already encodes the slope-adjusted front/back phase structure.",
        f"Most runs are single-bin events ({(one_bin/total_runs*100 if total_runs else 0):.1f}%).",
        f"Multi-bin runs are uncommon ({(multi_bin/total_runs*100 if total_runs else 0):.1f}% of all runs).",
        f"Cross-phase multi-bin runs are rare ({cross_phase_multi} cases).",
    ])
    summary_path = outdir / "analysis_summary.txt"
    summary_path.write_text(summary_text, encoding="utf-8")

    return {
        "global_summary": global_path,
        "local_all": local_all_path,
        "local_hotspots": hotspots_path,
        "pairs": pairs_path,
        "runs": runs_path,
        "run_length_summary": run_length_summary_path,
        "run_length_sector_summary": run_length_sector_path,
        "boundary_summary": boundary_summary_path,
        "phase_fig": phase_fig,
        "run_length_fig": run_length_fig,
        "multibin_fig": multibin_fig,
        "sig_fig": sig_fig,
        "cross_phase_fig": cross_phase_fig,
        "all_depth_local_fig": all_depth_local_fig,
        "summary": summary_path,
    }


def main() -> None:
    args = parse_args()
    input_path = Path(args.input)
    outdir = Path(args.output_dir)
    materials = [m.strip() for m in args.materials.split(",") if m.strip()]

    print(f"Loading input: {input_path}")
    df = load_input(input_path)
    print(f"Rows loaded: {len(df):,}")

    df = validate_and_prepare(df)
    print("Input validated.")
    print(f"Rows after duplicate handling: {len(df):,}")
    print(f"Analysing materials: {', '.join(materials)}")

    outputs = analyse(
        df=df,
        materials=materials,
        outdir=outdir,
        min_count=args.min_count,
        n_perm=args.n_perm,
        alpha=args.alpha,
    )

    print("\nAnalysis complete. Outputs:")
    for k, v in outputs.items():
        print(f" - {k}: {v}")


if __name__ == "__main__":
    main()
