@echo off
setlocal ENABLEEXTENSIONS

cd /d "%~dp0"
set LOGFILE=%~dp0run_log.txt
if exist "%LOGFILE%" del "%LOGFILE%"

echo Checking files...>> "%LOGFILE%"
echo Working directory: %CD%>> "%LOGFILE%"
echo.>> "%LOGFILE%"

set SCRIPT=run_madjedbebe_spatial_analysis.py
set INPUT=madjedbebe_final_aggregated_dataset.csv
set OUTDIR=madjedbebe_spatial_outputs

if not exist "%SCRIPT%" (
  echo ERROR: Could not find %SCRIPT%>> "%LOGFILE%"
  goto :fail
)

if not exist "%INPUT%" (
  echo ERROR: Could not find %INPUT%>> "%LOGFILE%"
  goto :fail
)

set PYTHON_CMD=
where py >nul 2>nul
if %ERRORLEVEL%==0 (
  set PYTHON_CMD=py -3
) else (
  where python >nul 2>nul
  if %ERRORLEVEL%==0 (
    set PYTHON_CMD=python
  )
)

if "%PYTHON_CMD%"=="" (
  echo ERROR: Python was not found on this computer.>> "%LOGFILE%"
  echo Install Python 3, then try again.>> "%LOGFILE%"
  goto :fail
)

echo Python command: %PYTHON_CMD%>> "%LOGFILE%"
echo Running analysis...>> "%LOGFILE%"
echo.>> "%LOGFILE%"

%PYTHON_CMD% "%SCRIPT%" --input "%INPUT%" --output-dir "%OUTDIR%" >> "%LOGFILE%" 2>&1
if %ERRORLEVEL% NEQ 0 goto :fail

echo.>> "%LOGFILE%"
echo Analysis complete.>> "%LOGFILE%"

if exist "%OUTDIR%" (
  start "" "%OUTDIR%"
)

echo Analysis completed successfully.
echo Results folder: %OUTDIR%
goto :eof

:fail
echo.
echo The analysis did not complete.
echo See "%LOGFILE%" for details.
echo.
type "%LOGFILE%"
echo.
pause
exit /b 1
