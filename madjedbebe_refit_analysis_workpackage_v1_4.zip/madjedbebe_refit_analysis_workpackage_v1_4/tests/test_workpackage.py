from __future__ import annotations

import math
import sys
from collections import Counter
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))

from analysis_core import (  # noqa: E402
    build_pairs,
    load_associations,
    load_background,
    load_intervals,
    load_json,
    load_measured_coordinates,
    load_metadata,
    load_polygons,
    simulate_coordinates,
)
from maximum_extent import (  # noqa: E402
    derive_interval_depth_bounds,
    entity_support_vertices,
    load_square_datums,
    maximum_pair_arrays,
    prepare_support_arrays,
)


def loaded():
    config = load_json(ROOT / "config/analysis_config.json")
    paths = {key: ROOT / value for key, value in config.items() if key.endswith("_file")}
    polygons = load_polygons(paths["square_polygons_file"])
    intervals = load_intervals(paths["vertical_intervals_file"])
    datums = load_square_datums(paths["square_surface_datums_file"])
    depth_bounds = derive_interval_depth_bounds(polygons, intervals, datums)
    metadata, completion = load_metadata(
        paths["site_square_spit_metadata_file"], intervals,
        paths["square_polygons_file"], paths["square_surface_datums_file"],
    )
    measured = load_measured_coordinates(paths["measured_silcrete_coordinates_file"])
    associations = load_associations(paths["association_file"], metadata, measured)
    background = load_background(
        paths["silcrete_7mm_background_file"], paths["measured_silcrete_coordinates_file"],
        metadata, {e.art_id for e in associations},
    )
    return config, polygons, intervals, datums, depth_bounds, metadata, completion, measured, associations, background


def test_definitive_v7_structure_and_pair_count():
    *_, associations, _ = loaded()
    assert len(associations) == 56
    assert len({e.set_id for e in associations}) == 26
    assert len({e.source_set_id for e in associations}) == 26
    assert len(build_pairs(associations)) == 35
    assert {e.association_group for e in associations} == {"Refit", "Conjoin"}


def test_analytical_set_key_is_association_code_and_one_to_one():
    config, *_, associations, _ = loaded()
    assert config["analytical_set_key"] == "association_type_new"
    mapping = {(e.source_set_id, e.set_id) for e in associations}
    assert len(mapping) == 26
    assert all(e.set_id == e.association_type for e in associations)


def test_artifact_identifiers_are_unique_and_resolved():
    *_, associations, _ = loaded()
    ids = [e.art_id for e in associations]
    keys = [e.key for e in associations]
    assert len(ids) == len(set(ids)) == 56
    assert len(keys) == len(set(keys)) == 56
    required = {
        "EGH2_1", "EGH2_2", "EGH2_3", "EGH2_4",
        "EGH3_1", "EGH3_2", "GS80_1", "GS80_2",
        "7MM_11", "L9325",
    }
    assert required.issubset(set(ids))
    assert "L9324" not in ids


def test_raw_material_composition():
    *_, associations, _ = loaded()
    expected = {
        "Silcrete": (29, 14, 16),
        "Quartzite": (6, 3, 3),
        "Dolerite": (6, 2, 7),
        "Dark grey quartzite": (3, 1, 3),
        "Chert": (2, 1, 1),
        "Brown quartzite": (2, 1, 1),
        "Oenpelli dolerite": (2, 1, 1),
        "Haematite": (2, 1, 1),
        "Quartz": (2, 1, 1),
        "Sandstone": (2, 1, 1),
    }
    observed = {}
    for material in {e.raw_material for e in associations}:
        subset = [e for e in associations if e.raw_material == material]
        observed[material] = (len(subset), len({e.set_id for e in subset}), len(build_pairs(subset)))
    assert observed == expected


def test_metadata_completion_and_interval_coverage():
    _, _, intervals, _, _, metadata, completion, _, associations, _ = loaded()
    for key in [("B4", "41"), ("B4", "43"), ("B4", "50"), ("D2", "39A")]:
        assert key in metadata
        assert metadata[key]["depth_m"] is not None
        assert metadata[key]["depth_10cm"] is not None
        assert metadata[key]["phase"]
        assert key in intervals and intervals[key].usable
    assert all((e.square, e.spit) in intervals for e in associations if e.provenance != "measured_total_station")
    assert all(e.depth_m is not None and e.phase for e in associations)
    completed = {(r["square"], r["spit"]) for r in completion}
    assert {("B4", "41"), ("B4", "43"), ("D2", "39A")}.issubset(completed)


def test_polygons_intervals_and_depth_bounds_are_valid():
    _, polygons, intervals, _, depth_bounds, *_ = loaded()
    assert len(polygons) == 20
    assert all(abs(p.area_m2 - 1.0) < 1e-6 for p in polygons.values())
    assert all(i.usable for i in intervals.values())
    assert all(lower >= upper for upper, lower in depth_bounds.values())


def test_measured_coordinates_fixed_and_imputed_coordinates_valid():
    _, polygons, intervals, *_rest = loaded()
    associations = _rest[-2]
    measured = next(e for e in associations if e.provenance == "measured_total_station")
    imputed = next(e for e in associations if e.provenance == "imputed_7mm_sieved")
    x, y, z = simulate_coordinates([measured, imputed], 100, np.random.default_rng(1234), polygons, intervals)
    assert np.allclose(x[:, 0], measured.x)
    assert np.allclose(y[:, 0], measured.y)
    assert np.allclose(z[:, 0], measured.z)
    polygon = polygons[imputed.square]
    matrix = np.column_stack([polygon.ne - polygon.nw, polygon.sw - polygon.nw])
    uv = (np.linalg.inv(matrix) @ np.column_stack([x[:, 1] - polygon.nw[0], y[:, 1] - polygon.nw[1]]).T).T
    assert np.all(uv >= -1e-10) and np.all(uv <= 1.0 + 1e-10)
    interval = intervals[(imputed.square, imputed.spit)]
    upper = interval.upper[0] + interval.upper[1] * x[:, 1] + interval.upper[2] * y[:, 1]
    lower = interval.lower[0] + interval.lower[1] * x[:, 1] + interval.lower[2] * y[:, 1]
    assert np.all(z[:, 1] >= lower - 1e-10)
    assert np.all(z[:, 1] <= upper + 1e-10)


def test_silcrete_null_population_and_exclusion():
    *_, measured, associations, background = loaded()
    associated_ids = {e.art_id for e in associations}
    assert not ({e.art_id for e in background} & associated_ids)
    assert len(background) == 3069
    assert len(measured) == 113
    assert all(e.raw_material == "Silcrete" for e in background)
    silcrete = [e for e in associations if e.raw_material == "Silcrete"]
    assert len(silcrete) == 29
    assert len({e.set_id for e in silcrete}) == 14
    assert len(build_pairs(silcrete)) == 16


def test_strict_null_exclusion_is_only_refit_a():
    *_, associations, background = loaded()
    pools = {(e.square, e.phase) for e in background}
    excluded = {
        e.set_id for e in associations
        if e.raw_material == "Silcrete" and (e.square, e.phase) not in pools
    }
    assert excluded == {"Refit A"}


def test_maximum_extent_same_square_same_spit_uses_full_support():
    _, polygons, intervals, datums, depth_bounds, *_rest = loaded()
    associations = _rest[-2]
    members = [e for e in associations if e.set_id == "Refit D"]
    assert len(members) == 2
    assert all(e.provenance == "imputed_7mm_sieved" for e in members)
    pairs = build_pairs(members)
    vertices, depths = prepare_support_arrays(members, polygons, intervals, depth_bounds, datums)
    metrics = maximum_pair_arrays(vertices, depths, pairs)
    assert math.isclose(float(metrics["maximum_horizontal_distance_m"][0, 0]), math.sqrt(2.0), abs_tol=1e-6)
    upper, lower = depth_bounds[("B4", "43")]
    assert math.isclose(
        float(metrics["maximum_stratigraphic_depth_separation_cm"][0, 0]),
        (lower - upper) * 100.0, abs_tol=1e-8,
    )


def test_maximum_extent_measured_pair_uses_fixed_points():
    _, polygons, intervals, datums, depth_bounds, *_rest = loaded()
    associations = _rest[-2]
    members = [e for e in associations if e.set_id == "Refit A"]
    assert len(members) == 2
    assert all(e.provenance == "measured_total_station" for e in members)
    supports = [entity_support_vertices(e, polygons, intervals) for e in members]
    assert all(np.allclose(s, s[0]) for s in supports)
    pairs = build_pairs(members)
    vertices, depths = prepare_support_arrays(members, polygons, intervals, depth_bounds, datums)
    metrics = maximum_pair_arrays(vertices, depths, pairs)
    dx, dy, dz = members[1].x - members[0].x, members[1].y - members[0].y, members[1].z - members[0].z
    assert math.isclose(float(metrics["maximum_horizontal_distance_m"][0, 0]), math.hypot(dx, dy), abs_tol=1e-12)
    assert math.isclose(float(metrics["maximum_vertical_elevation_separation_cm"][0, 0]), abs(dz) * 100.0, abs_tol=1e-10)


def test_maximum_3d_distance_is_compatible_and_bounded():
    _, polygons, intervals, datums, depth_bounds, *_rest = loaded()
    associations = _rest[-2]
    pairs = build_pairs(associations)
    vertices, depths = prepare_support_arrays(associations, polygons, intervals, depth_bounds, datums)
    metrics = maximum_pair_arrays(vertices, depths, pairs)
    h = metrics["maximum_horizontal_distance_m"]
    v = metrics["maximum_vertical_elevation_separation_cm"] / 100.0
    d3 = metrics["maximum_distance_3d_m"]
    assert np.all(d3 <= np.sqrt(h * h + v * v) + 1e-10)
    assert np.all(d3 >= h - 1e-10)
    assert np.all(d3 >= v - 1e-10)


def test_configuration_has_no_age_or_extra_slope_model():
    config, *_ = loaded()
    assert config["age_analysis_enabled"] is False
    assert config["additional_slope_correction_enabled"] is False
    assert config["maximum_extent_analysis_enabled"] is True


def test_package_contains_only_definitive_association_input():
    association_files = sorted((ROOT / "input").glob("Refits_conjoins_all*.csv"))
    assert [p.name for p in association_files] == ["Refits_conjoins_all_v7_codes_FINAL.csv"]
    assert len(association_files) == 1
