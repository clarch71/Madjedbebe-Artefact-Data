# Build verification

The definitive workpackage was validated against `Refits_conjoins_all_v7_codes_FINAL.csv`.

## Input structure

- 56 artefact rows
- 56 unique artefact identifiers
- 26 analytical associations
- 26 source set labels
- 35 unordered pairwise links
- 29 silcrete artefacts in 14 associations, producing 16 links
- 10 represented raw-material categories

The analytical association key is `association_type_new`. Each source set label maps one-to-one to one analytical association.

## Spatial inputs

- 113 validated measured plotted-silcrete records
- 20 fitted square polygons, each 1 m²
- complete usable vertical-interval coverage for all unmeasured association artefacts
- 3,069 silcrete null-population artefacts after removal of all associated silcrete artefacts

## Statistical models

- 10,000 standard coordinate-imputation iterations
- 10,000 standard silcrete matched-randomisation iterations
- 10,000 maximum-extent silcrete matched-randomisation iterations
- 13 strict-null-eligible silcrete associations
- Refit A retained descriptively and excluded from the strict null because no unassociated C4 Phase 1 comparator exists

## Validation and reproducibility

- 30 runtime validation checks passed
- 14 automated tests passed
- zero hard validation failures
- two independent complete runs produced the same 33 output files
- all 33 output files were byte-for-byte identical between runs

The package contains one definitive association input and no alternative association-analysis branch.
