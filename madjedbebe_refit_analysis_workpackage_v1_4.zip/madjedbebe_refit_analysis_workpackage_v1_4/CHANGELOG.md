# Changelog

## 1.4.0

Clean definitive release for `Refits_conjoins_all_v7_codes_FINAL.csv`.

- Uses one association catalogue containing 56 artefacts in 26 refit/conjoin associations.
- Uses `association_type_new` as the analytical association key and retains `set_id_new` only as a source label.
- Validates all 56 artefact identifiers as unique, including the resolved EGH2, EGH3 and GS80 identifiers.
- Includes all represented raw materials in observed descriptive analyses.
- Restricts formal matched randomisation to silcrete.
- Implements both repeated-coordinate-imputation and maximum-extent upper-bound models.
- Includes exact pinned dependencies, automated tests, input checksums and deterministic run verification.
