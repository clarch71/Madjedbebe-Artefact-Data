# Madjedbebe refit and conjoin analysis workpackage v1.4.0

## Purpose

This workpackage reproduces the spatial analysis of the definitive Madjedbebe refit and conjoin catalogue. It contains a single association analysis based on `Refits_conjoins_all_v7_codes_FINAL.csv` and does not include any alternative association catalogue.

The workpackage performs:

1. an all-material descriptive analysis of every refit and conjoin association;
2. a silcrete-only matched randomisation analysis, because a complete unassociated comparison population is available for silcrete;
3. a standard repeated-coordinate-imputation model; and
4. a maximum-extent upper-bound sensitivity model.

## Definitive analysis population

The association input contains:

- 56 artefacts;
- 26 associations;
- 35 unordered pairwise links;
- 29 silcrete artefacts in 14 associations, producing 16 links.

All raw materials are retained in the observed descriptive analyses. Formal matched randomisation is restricted to silcrete.

The analytical association key is `association_type_new` (for example, `Refit A` or `Conjoin M`). `set_id_new` is retained only as a source-table label. This one-to-one distinction is validated before analysis.

## Inputs

### Association catalogue

`input/Refits_conjoins_all_v7_codes_FINAL.csv`

Defines association membership, association group, unique artefact identifier, excavation square, spit and raw material.

### Silcrete comparison population

`input/MJB_silcrete_all_unique_ArtID_codes.csv`

Contains 2,960 unassociated 7-mm silcrete artefacts with square, spit, depth below surface, 10-cm depth unit and phase metadata.

### Measured plotted silcrete artefacts

`input/silcrete_artefacts_spatial_data_Xnew_Ynew_all_plotted_v4.csv`

Contains 113 plotted silcrete artefacts with validated measured `Xnew`, `Ynew` and elevation coordinates. Coordinates of plotted association artefacts present in this file are held fixed throughout all simulations.

### Square–spit metadata

`input/site_square_spit_depth_phase_metadata_v2.csv`

Provides the authoritative square–spit depth below surface, 10-cm depth unit and phase assignments. Age columns are ignored.

### Derived spatial controls

The `derived_inputs` directory contains fixed outputs from the validated end-level preparation workflow:

- `square_grid_polygons.csv`;
- `square_spit_vertical_intervals.csv`;
- `square_spit_vertical_surfaces.csv`;
- `square_surface_datums.csv`; and
- `end_level_input_provenance.json`.

These files define exact 1-m² square polygons and usable upper and lower vertical interval planes.

## Coordinate provenance

Each association artefact is assigned one of three coordinate-provenance classes:

- `measured_total_station`: validated plotted silcrete artefact with fixed measured `x`, `y` and `z`;
- `imputed_7mm_sieved`: artefact with square–spit provenance but no measured within-volume coordinate; or
- `imputed_plotted_coordinate_unavailable`: plotted or catalogue-coded artefact for which a measured coordinate is unavailable in the supplied plotted-silcrete file.

The latter two classes are treated identically for spatial imputation but remain separately labelled in the outputs.

## Standard repeated-imputation model

Measured total-station coordinates remain fixed. For every unmeasured artefact and every iteration:

1. a horizontal position is sampled uniformly inside its fitted 1-m² square polygon;
2. the upper and lower interval planes are evaluated at that same horizontal position;
3. elevation is sampled uniformly between the two planes; and
4. the resulting `x`, `y`, `z` point is retained for that artefact throughout the iteration.

The process is repeated for 10,000 iterations using the fixed master seed `20260614`.

For each unordered pair within an association, the model calculates:

- horizontal distance;
- absolute elevation separation;
- three-dimensional Euclidean distance;
- plunge angle;
- square–spit metadata depth separation;
- same-phase status; and
- same-10-cm-depth-unit status.

For associations with more than two artefacts, pairwise values are reduced to an association-level median in each iteration. The global statistic is the median of association-level medians, so every association receives equal inferential weight.

## Maximum-extent sensitivity model

The upper-bound model uses the complete permissible spatial support of each unmeasured artefact.

- A measured plotted artefact is represented by its fixed measured point.
- An unmeasured artefact is represented by the eight vertices of its square–spit volume: the four square-polygon vertices evaluated on both the upper and lower interval planes.

For each pair, the model calculates the exact maximum compatible:

- horizontal distance;
- topography-relative stratigraphic-depth separation;
- elevation separation;
- three-dimensional distance; and
- vertex-to-vertex plunge.

For two unmeasured artefacts from the same square, maximum horizontal separation is the complete square diagonal. For two unmeasured artefacts in the same spit interval, maximum stratigraphic-depth separation is the full validated interval thickness. For different intervals, the calculation spans the complete support of both intervals. Maximum 3-D distance is calculated from compatible support vertices rather than by combining independently maximal horizontal and vertical values.

This model is deliberately conservative and represents an upper bound, not an estimate of actual artefact position.

## Silcrete matched randomisation

The silcrete null population combines:

- 2,960 unassociated 7-mm silcrete artefacts; and
- 109 non-associated plotted silcrete artefacts.

All 29 associated silcrete artefacts are excluded, leaving 3,069 comparison artefacts.

Each observed silcrete endpoint is matched to an unassociated silcrete artefact from the same square and phase. Sampling is without replacement within each square–phase cell during an iteration and is allowed to repeat between iterations. Spit and depth are not matching variables because they are outcomes or direct proxies for the vertical outcome.

The identical endpoint matching and association-level weighting are applied to the standard and maximum-extent models. Refit A remains in all observed outputs but is excluded from the strict matched null because one endpoint has no unassociated C4 Phase 1 comparator. The strict null therefore contains 13 silcrete associations.

Empirical lower-tail probabilities are calculated as:

`(1 + number of iterations in which null <= observed) / (iterations + 1)`.

Small values indicate that observed association sets are more spatially compact or lower-plunging than their matched null analogues.

## Authoritative stratigraphic metadata

`Depth m`, `Depth 10cm` and `Phase` are treated as authoritative. Imputed elevation is used only for fine-scale elevation, 3-D-distance and plunge analyses. The pipeline does not:

- recalculate phase;
- analyse age;
- apply an additional topographic slope correction; or
- use end-level elevations as substitutes for artefact depth metadata.

## Running the package on Windows

Double-click:

`run_analysis_click_me.bat`

The runner installs the exact pinned dependencies, executes both models, runs the matched randomisations and then runs the automated tests.

To run the tests only, double-click:

`run_tests_click_me.bat`

## Command-line use

From the package directory:

```bash
python -m pip install -r requirements.txt
python scripts/run_analysis.py
python -m pytest -q
```

For a short diagnostic run:

```bash
python scripts/run_analysis.py --iterations 100
```

## Output structure

- `output/all_material_standard_imputation/`: pairwise, association-level and global standard-model summaries;
- `output/all_material_maximum_extent/`: pairwise, association-level and global maximum-extent summaries;
- `output/silcrete_standard_randomisation/`: strict silcrete null results for the standard model;
- `output/silcrete_maximum_extent_randomisation/`: strict silcrete null results for the maximum model;
- `output/standard_vs_maximum_comparison/`: link-level comparison of the two models;
- `output/raw_material_descriptive_summary/`: descriptive summaries for every represented raw material;
- `output/validation/`: metadata completion, polygon audit and validation report; and
- `output/figures/`: figures generated during the run.

## Validation

The test suite checks, among other requirements:

- 56 unique artefact identifiers;
- 26 one-to-one analytical associations;
- 35 pairwise links;
- exact raw-material composition;
- complete metadata and vertical-interval coverage;
- exact 1-m² polygon areas;
- fixed measured coordinates;
- imputed points within valid polygons and intervals;
- exclusion of all association artefacts from the silcrete null population;
- the data-driven Refit A null exclusion;
- maximum-extent upper-bound behaviour; and
- absence of alternative association inputs.

All dependency versions are pinned in `requirements.txt`.
