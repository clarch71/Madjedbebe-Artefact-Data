from __future__ import annotations

import csv
import hashlib
import itertools
import json
import math
import os
import re
from collections import Counter, defaultdict
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable

import numpy as np


@dataclass(frozen=True)
class Polygon:
    square: str
    nw: np.ndarray
    ne: np.ndarray
    sw: np.ndarray
    area_m2: float
    quality_flag: str


@dataclass(frozen=True)
class Interval:
    square: str
    spit: str
    upper: tuple[float, float, float]
    lower: tuple[float, float, float]
    usable: bool
    sampling_model: str
    quality_flag: str
    depth_m: float | None


@dataclass
class Entity:
    art_id: str
    square: str
    spit: str
    raw_material: str
    phase: str
    depth_m: float
    depth_10cm: float
    provenance: str
    x: float | None = None
    y: float | None = None
    z: float | None = None
    set_id: str = ""
    source_set_id: str = ""
    association_type: str = ""
    association_group: str = ""

    @property
    def key(self) -> tuple[str, str, str]:
        return (self.art_id, self.square, self.spit)


@dataclass(frozen=True)
class PairDef:
    pair_index: int
    set_id: str
    i: int
    j: int


METRIC_NAMES = [
    "horizontal_distance_m",
    "vertical_elevation_separation_cm",
    "distance_3d_m",
    "plunge_deg",
]


def norm_text(value: Any) -> str:
    return "" if value is None else str(value).strip()


def norm_id(value: Any) -> str:
    return norm_text(value).upper()


def norm_square(value: Any) -> str:
    return norm_text(value).upper()


def norm_spit(value: Any) -> str:
    return norm_text(value).upper()


def norm_phase(value: Any) -> str:
    s = norm_text(value)
    if not s:
        return ""
    try:
        f = float(s)
        if f.is_integer():
            return str(int(f))
    except ValueError:
        pass
    return s.replace("Phase", "").strip()


def parse_float(value: Any, field: str, allow_blank: bool = False) -> float | None:
    s = norm_text(value)
    if not s and allow_blank:
        return None
    try:
        return float(s)
    except Exception as exc:
        raise ValueError(f"Invalid numeric value for {field}: {value!r}") from exc


def bool_true(value: Any) -> bool:
    return norm_text(value).upper() in {"TRUE", "1", "YES", "Y"}


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle))


def write_csv(path: Path, rows: Iterable[dict[str, Any]], fieldnames: list[str] | None = None) -> None:
    rows = list(rows)
    path.parent.mkdir(parents=True, exist_ok=True)
    if fieldnames is None:
        if not rows:
            raise ValueError(f"Cannot infer fieldnames for empty output: {path}")
        fieldnames = list(rows[0].keys())
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def load_json(path: Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def require_columns(rows: list[dict[str, str]], required: Iterable[str], label: str) -> None:
    if not rows:
        raise ValueError(f"{label} contains no data rows")
    missing = [name for name in required if name not in rows[0]]
    if missing:
        raise ValueError(f"{label} is missing required columns: {missing}")


def numeric_set_sort(value: str) -> tuple[int, str]:
    """Stable ordering for definitive association codes (Refit A, Conjoin A, ...)."""
    text = norm_text(value)
    group_rank = 0 if text.upper().startswith("REFIT") else 1 if text.upper().startswith("CONJOIN") else 2
    return (group_rank, text.upper())


def load_polygons(path: Path) -> dict[str, Polygon]:
    rows = read_csv(path)
    require_columns(
        rows,
        ["square", "NW_Xnew", "NW_Ynew", "NE_Xnew", "NE_Ynew", "SW_Xnew", "SW_Ynew", "polygon_area_m2", "quality_flag"],
        "square polygons",
    )
    polygons: dict[str, Polygon] = {}
    for row in rows:
        square = norm_square(row["square"])
        if square in polygons:
            raise ValueError(f"Duplicate square polygon: {square}")
        polygons[square] = Polygon(
            square=square,
            nw=np.array([float(row["NW_Xnew"]), float(row["NW_Ynew"])], dtype=float),
            ne=np.array([float(row["NE_Xnew"]), float(row["NE_Ynew"])], dtype=float),
            sw=np.array([float(row["SW_Xnew"]), float(row["SW_Ynew"])], dtype=float),
            area_m2=float(row["polygon_area_m2"]),
            quality_flag=norm_text(row["quality_flag"]),
        )
    return polygons


def load_intervals(path: Path) -> dict[tuple[str, str], Interval]:
    rows = read_csv(path)
    require_columns(
        rows,
        [
            "square", "spit_label", "upper_plane_a_intercept", "upper_plane_b_Xnew", "upper_plane_c_Ynew",
            "lower_plane_a_intercept", "lower_plane_b_Xnew", "lower_plane_c_Ynew",
            "vertical_interval_usable", "interval_sampling_model", "quality_flag", "depth_m_below_surface",
        ],
        "vertical intervals",
    )
    intervals: dict[tuple[str, str], Interval] = {}
    for row in rows:
        key = (norm_square(row["square"]), norm_spit(row["spit_label"]))
        if key in intervals:
            raise ValueError(f"Duplicate vertical interval: {key}")
        intervals[key] = Interval(
            square=key[0],
            spit=key[1],
            upper=(float(row["upper_plane_a_intercept"]), float(row["upper_plane_b_Xnew"]), float(row["upper_plane_c_Ynew"])),
            lower=(float(row["lower_plane_a_intercept"]), float(row["lower_plane_b_Xnew"]), float(row["lower_plane_c_Ynew"])),
            usable=bool_true(row["vertical_interval_usable"]),
            sampling_model=norm_text(row["interval_sampling_model"]),
            quality_flag=norm_text(row["quality_flag"]),
            depth_m=parse_float(row["depth_m_below_surface"], "interval depth_m", allow_blank=True),
        )
    return intervals


def _ceil_tenth(value: float) -> float:
    return math.ceil((value * 10.0) - 1e-9) / 10.0


def load_metadata(
    site_metadata_path: Path,
    intervals: dict[tuple[str, str], Interval],
    polygons_path: Path,
    datums_path: Path,
) -> tuple[dict[tuple[str, str], dict[str, Any]], list[dict[str, Any]]]:
    rows = read_csv(site_metadata_path)
    require_columns(rows, ["Square", "Spit", "Depth m", "Depth 10cm", "Phase"], "site square-spit metadata")
    lookup: dict[tuple[str, str], dict[str, Any]] = {}
    for source_row, row in enumerate(rows, start=2):
        square, spit = norm_square(row["Square"]), norm_spit(row["Spit"])
        if not square or not spit:
            continue
        depth = parse_float(row["Depth m"], "Depth m", allow_blank=True)
        depth_10 = parse_float(row["Depth 10cm"], "Depth 10cm", allow_blank=True)
        phase = norm_phase(row["Phase"])
        key = (square, spit)
        candidate = {
            "square": square,
            "spit": spit,
            "depth_m": depth,
            "depth_10cm": depth_10,
            "phase": phase,
            "source": "site_square_spit_depth_phase_metadata_v2",
            "source_row": source_row,
        }
        if key not in lookup or sum(v not in (None, "") for v in candidate.values()) > sum(v not in (None, "") for v in lookup[key].values()):
            lookup[key] = candidate

    polygon_rows = read_csv(polygons_path)
    polygon_centres = {
        norm_square(r["square"]): (float(r["centre_Xnew"]), float(r["centre_Ynew"])) for r in polygon_rows
    }
    datum_rows = read_csv(datums_path)
    datums = {
        norm_square(r["square"]): (
            float(r["datum_plane_a_intercept"]), float(r["datum_plane_b_Xnew"]), float(r["datum_plane_c_Ynew"])
        ) for r in datum_rows
    }

    completion_audit: list[dict[str, Any]] = []
    needed_keys = {key for key in intervals if key not in lookup or lookup[key]["depth_m"] is None or lookup[key]["depth_10cm"] is None or not lookup[key]["phase"]}
    for key in sorted(needed_keys):
        square, spit = key
        interval = intervals[key]
        existing = lookup.get(key, {"square": square, "spit": spit, "depth_m": None, "depth_10cm": None, "phase": "", "source": "", "source_row": ""})
        depth = existing["depth_m"]
        method_parts: list[str] = []
        if depth is None:
            if interval.depth_m is not None:
                depth = interval.depth_m
                method_parts.append("depth_from_validated_interval_metadata")
            elif square in polygon_centres and square in datums:
                x, y = polygon_centres[square]
                da, db, dc = datums[square]
                la, lb, lc = interval.lower
                datum_z = da + db * x + dc * y
                lower_z = la + lb * x + lc * y
                depth = datum_z - lower_z
                method_parts.append("depth_derived_from_square_datum_minus_interval_lower_plane_at_square_centre")
        phase = existing["phase"]
        if not phase:
            numeric_match = re.match(r"^(\d+)", spit)
            if numeric_match:
                target = float(numeric_match.group(1)) + (0.5 if spit.endswith("A") else 0.0)
                candidates: list[tuple[float, str]] = []
                for (sq2, sp2), meta in lookup.items():
                    if sq2 != square or not meta["phase"]:
                        continue
                    m2 = re.match(r"^(\d+)", sp2)
                    if not m2:
                        continue
                    pos = float(m2.group(1)) + (0.5 if sp2.endswith("A") else 0.0)
                    candidates.append((abs(pos - target), meta["phase"]))
                candidates.sort(key=lambda item: item[0])
                if candidates:
                    nearest_distance = candidates[0][0]
                    nearest_phases = {p for d, p in candidates if abs(d - nearest_distance) < 1e-12}
                    if len(nearest_phases) == 1:
                        phase = next(iter(nearest_phases))
                        method_parts.append("phase_from_nearest_same_square_spit_metadata")
                    else:
                        # If equally near bracketing records agree, use their phase.
                        closest_two = [p for _, p in candidates[:2]]
                        if len(set(closest_two)) == 1:
                            phase = closest_two[0]
                            method_parts.append("phase_from_agreeing_bracketing_same_square_spits")
        depth_10 = existing["depth_10cm"]
        if depth_10 is None and depth is not None:
            depth_10 = _ceil_tenth(depth)
            method_parts.append("depth_10cm_ceiling_from_depth_m")
        if depth is not None and phase:
            lookup[key] = {
                "square": square,
                "spit": spit,
                "depth_m": float(depth),
                "depth_10cm": float(depth_10) if depth_10 is not None else None,
                "phase": phase,
                "source": existing["source"] or "validated_end_level_interval_completion",
                "source_row": existing["source_row"],
            }
            if method_parts:
                completion_audit.append({
                    "square": square,
                    "spit": spit,
                    "depth_m": round(float(depth), 9),
                    "depth_10cm": round(float(depth_10), 3) if depth_10 is not None else "",
                    "phase": phase,
                    "completion_methods": ";".join(method_parts),
                    "interval_sampling_model": interval.sampling_model,
                    "interval_quality_flag": interval.quality_flag,
                })
    return lookup, completion_audit


def load_measured_coordinates(path: Path) -> dict[tuple[str, str, str], Entity]:
    rows = read_csv(path)
    require_columns(rows, ["ArtID_norm", "xnew", "ynew", "elevation", "Square", "Spit", "Depth m", "Depth 10cm", "Phase"], "measured coordinates")
    lookup: dict[tuple[str, str, str], Entity] = {}
    ids: set[str] = set()
    for row in rows:
        art_id = norm_id(row["ArtID_norm"])
        square, spit = norm_square(row["Square"]), norm_spit(row["Spit"])
        key = (art_id, square, spit)
        if key in lookup:
            raise ValueError(f"Duplicate measured composite key: {key}")
        if art_id in ids:
            raise ValueError(f"Duplicate measured ArtID: {art_id}")
        ids.add(art_id)
        lookup[key] = Entity(
            art_id=art_id,
            square=square,
            spit=spit,
            raw_material="Silcrete",
            phase=norm_phase(row["Phase"]),
            depth_m=float(row["Depth m"]),
            depth_10cm=float(row["Depth 10cm"]),
            provenance="measured_total_station",
            x=float(row["xnew"]), y=float(row["ynew"]), z=float(row["elevation"]),
        )
    return lookup


def load_associations(
    path: Path,
    metadata: dict[tuple[str, str], dict[str, Any]],
    measured: dict[tuple[str, str, str], Entity],
) -> list[Entity]:
    rows = read_csv(path)
    require_columns(
        rows,
        ["set_id_new", "association_type_new", "association_group", "include_in_refit_conjoin_analysis", "ArtID_norm_new", "Square", "Spit_raw", "Raw Material"],
        f"association file {path.name}",
    )
    entities: list[Entity] = []
    seen_ids: set[str] = set()
    seen_keys: set[tuple[str, str, str]] = set()
    for row in rows:
        if not bool_true(row["include_in_refit_conjoin_analysis"]):
            raise ValueError(f"All rows must be TRUE in {path.name}; found FALSE for {row['ArtID_norm_new']}")
        art_id = norm_id(row["ArtID_norm_new"])
        square, spit = norm_square(row["Square"]), norm_spit(row["Spit_raw"])
        key = (art_id, square, spit)
        if art_id in seen_ids:
            raise ValueError(f"Duplicate association ArtID in {path.name}: {art_id}")
        if key in seen_keys:
            raise ValueError(f"Duplicate association composite key in {path.name}: {key}")
        seen_ids.add(art_id); seen_keys.add(key)
        meta = metadata.get((square, spit))
        if not meta or meta["depth_m"] is None or meta["depth_10cm"] is None or not meta["phase"]:
            raise ValueError(f"Missing complete depth/phase metadata for association {key}")
        measured_entity = measured.get(key)
        if measured_entity is not None:
            provenance = "measured_total_station"
            x, y, z = measured_entity.x, measured_entity.y, measured_entity.z
        else:
            provenance = "imputed_7mm_sieved" if art_id.startswith("7MM_") else "imputed_plotted_coordinate_unavailable"
            x = y = z = None
        entities.append(Entity(
            art_id=art_id,
            square=square,
            spit=spit,
            raw_material=norm_text(row["Raw Material"]).strip(),
            phase=norm_phase(meta["phase"]),
            depth_m=float(meta["depth_m"]),
            depth_10cm=float(meta["depth_10cm"]),
            provenance=provenance,
            x=x, y=y, z=z,
            set_id=norm_text(row["association_type_new"]),
            source_set_id=norm_text(row["set_id_new"]),
            association_type=norm_text(row["association_type_new"]),
            association_group=norm_text(row["association_group"]),
        ))
    return entities


def load_background(
    background_path: Path,
    measured_path: Path,
    metadata: dict[tuple[str, str], dict[str, Any]],
    associated_ids: set[str],
) -> list[Entity]:
    background_rows = read_csv(background_path)
    require_columns(background_rows, ["ArtID", "Raw Material", "Square", "Spit", "Depth m", "Depth 10cm", "Phase"], "silcrete 7mm background")
    entities: list[Entity] = []
    seen: set[str] = set()
    for row in background_rows:
        art_id = norm_id(row["ArtID"])
        if art_id in associated_ids:
            continue
        if art_id in seen:
            raise ValueError(f"Duplicate background ArtID: {art_id}")
        seen.add(art_id)
        square, spit = norm_square(row["Square"]), norm_spit(row["Spit"])
        depth = parse_float(row["Depth m"], "background Depth m")
        depth_10 = parse_float(row["Depth 10cm"], "background Depth 10cm")
        phase = norm_phase(row["Phase"])
        entities.append(Entity(
            art_id=art_id, square=square, spit=spit, raw_material="Silcrete",
            phase=phase, depth_m=float(depth), depth_10cm=float(depth_10),
            provenance="imputed_7mm_sieved",
        ))
    measured_rows = read_csv(measured_path)
    for row in measured_rows:
        art_id = norm_id(row["ArtID_norm"])
        if art_id in associated_ids:
            continue
        if art_id in seen:
            raise ValueError(f"ArtID overlaps background sources: {art_id}")
        seen.add(art_id)
        entities.append(Entity(
            art_id=art_id,
            square=norm_square(row["Square"]),
            spit=norm_spit(row["Spit"]),
            raw_material="Silcrete",
            phase=norm_phase(row["Phase"]),
            depth_m=float(row["Depth m"]),
            depth_10cm=float(row["Depth 10cm"]),
            provenance="measured_total_station",
            x=float(row["xnew"]), y=float(row["ynew"]), z=float(row["elevation"]),
        ))
    return entities


def build_pairs(entities: list[Entity]) -> list[PairDef]:
    by_set: dict[str, list[int]] = defaultdict(list)
    for idx, entity in enumerate(entities):
        by_set[entity.set_id].append(idx)
    pairs: list[PairDef] = []
    pair_index = 0
    for set_id in sorted(by_set, key=numeric_set_sort):
        indices = by_set[set_id]
        if len(indices) < 2:
            raise ValueError(f"Set has fewer than two artefacts: {set_id}")
        materials = {entities[i].raw_material for i in indices}
        if len(materials) != 1:
            raise ValueError(f"Set mixes raw materials: {set_id} -> {materials}")
        for i, j in itertools.combinations(indices, 2):
            pairs.append(PairDef(pair_index=pair_index, set_id=set_id, i=i, j=j))
            pair_index += 1
    return pairs


def _evaluate_plane(coeffs: tuple[float, float, float], x: np.ndarray | float, y: np.ndarray | float) -> np.ndarray | float:
    a, b, c = coeffs
    return a + b * x + c * y


def simulate_coordinates(
    entities: list[Entity],
    n_iterations: int,
    rng: np.random.Generator,
    polygons: dict[str, Polygon],
    intervals: dict[tuple[str, str], Interval],
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    n = len(entities)
    x = np.empty((n_iterations, n), dtype=float)
    y = np.empty((n_iterations, n), dtype=float)
    z = np.empty((n_iterations, n), dtype=float)
    for idx, entity in enumerate(entities):
        if entity.provenance == "measured_total_station":
            if entity.x is None or entity.y is None or entity.z is None:
                raise ValueError(f"Measured entity lacks coordinates: {entity.art_id}")
            x[:, idx] = entity.x; y[:, idx] = entity.y; z[:, idx] = entity.z
            continue
        polygon = polygons.get(entity.square)
        interval = intervals.get((entity.square, entity.spit))
        if polygon is None:
            raise ValueError(f"No polygon for imputed entity {entity.art_id} in {entity.square}")
        if interval is None or not interval.usable:
            raise ValueError(f"No usable vertical interval for imputed entity {entity.art_id} at {(entity.square, entity.spit)}")
        uvw = rng.random((n_iterations, 3))
        east = polygon.ne - polygon.nw
        south = polygon.sw - polygon.nw
        xy = polygon.nw + uvw[:, [0]] * east + uvw[:, [1]] * south
        xi, yi = xy[:, 0], xy[:, 1]
        upper_z = _evaluate_plane(interval.upper, xi, yi)
        lower_z = _evaluate_plane(interval.lower, xi, yi)
        if np.any(upper_z < lower_z - 1e-10):
            raise ValueError(f"Inverted interval during sampling for {(entity.square, entity.spit)}")
        zi = lower_z + uvw[:, 2] * (upper_z - lower_z)
        x[:, idx] = xi; y[:, idx] = yi; z[:, idx] = zi
    return x, y, z


def pair_metric_arrays(x: np.ndarray, y: np.ndarray, z: np.ndarray, pairs: list[PairDef]) -> dict[str, np.ndarray]:
    i = np.array([p.i for p in pairs], dtype=int)
    j = np.array([p.j for p in pairs], dtype=int)
    dx = x[:, j] - x[:, i]
    dy = y[:, j] - y[:, i]
    dz = z[:, j] - z[:, i]
    horizontal = np.sqrt(dx * dx + dy * dy)
    vertical_cm = np.abs(dz) * 100.0
    distance3d = np.sqrt(horizontal * horizontal + dz * dz)
    plunge = np.degrees(np.arctan2(np.abs(dz), horizontal))
    return {
        "horizontal_distance_m": horizontal,
        "vertical_elevation_separation_cm": vertical_cm,
        "distance_3d_m": distance3d,
        "plunge_deg": plunge,
    }


def fixed_pair_metadata(entities: list[Entity], pairs: list[PairDef]) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for pair in pairs:
        a, b = entities[pair.i], entities[pair.j]
        rows.append({
            "pair_index": pair.pair_index,
            "association_id": pair.set_id,
            "source_set_id": a.source_set_id,
            "association_code": a.association_type,
            "association_group": a.association_group,
            "raw_material": a.raw_material,
            "art_id_a": a.art_id,
            "art_id_b": b.art_id,
            "square_a": a.square,
            "square_b": b.square,
            "spit_a": a.spit,
            "spit_b": b.spit,
            "phase_a": a.phase,
            "phase_b": b.phase,
            "same_phase": a.phase == b.phase,
            "depth_m_a": a.depth_m,
            "depth_m_b": b.depth_m,
            "depth_separation_cm": abs(a.depth_m - b.depth_m) * 100.0,
            "depth_10cm_a": a.depth_10cm,
            "depth_10cm_b": b.depth_10cm,
            "same_depth_10cm_unit": math.isclose(a.depth_10cm, b.depth_10cm, abs_tol=1e-9),
            "coordinate_provenance_a": a.provenance,
            "coordinate_provenance_b": b.provenance,
            "both_coordinates_measured": a.provenance == b.provenance == "measured_total_station",
        })
    return rows


def quantile_summary(values: np.ndarray) -> tuple[float, float, float, float]:
    return (
        float(np.mean(values)),
        float(np.quantile(values, 0.025)),
        float(np.quantile(values, 0.5)),
        float(np.quantile(values, 0.975)),
    )


def set_stat_iterations(metric_array: np.ndarray, pairs: list[PairDef]) -> tuple[np.ndarray, dict[str, np.ndarray]]:
    by_set_cols: dict[str, list[int]] = defaultdict(list)
    for col, pair in enumerate(pairs):
        by_set_cols[pair.set_id].append(col)
    set_arrays: dict[str, np.ndarray] = {
        set_id: np.median(metric_array[:, cols], axis=1) for set_id, cols in by_set_cols.items()
    }
    matrix = np.column_stack([set_arrays[s] for s in sorted(set_arrays, key=numeric_set_sort)])
    return np.median(matrix, axis=1), set_arrays


def depth_set_stat(entities: list[Entity], pairs: list[PairDef]) -> tuple[float, dict[str, float]]:
    by_set: dict[str, list[float]] = defaultdict(list)
    for pair in pairs:
        by_set[pair.set_id].append(abs(entities[pair.i].depth_m - entities[pair.j].depth_m) * 100.0)
    set_medians = {s: float(np.median(v)) for s, v in by_set.items()}
    return float(np.median(list(set_medians.values()))), set_medians


def simulate_observed(
    analysis_name: str,
    entities: list[Entity],
    n_iterations: int,
    seed: int,
    polygons: dict[str, Polygon],
    intervals: dict[tuple[str, str], Interval],
    output_dir: Path,
) -> dict[str, Any]:
    pairs = build_pairs(entities)
    rng = np.random.default_rng(seed)
    x, y, z = simulate_coordinates(entities, n_iterations, rng, polygons, intervals)
    metrics = pair_metric_arrays(x, y, z, pairs)
    fixed_rows = fixed_pair_metadata(entities, pairs)
    pair_rows: list[dict[str, Any]] = []
    for col, base in enumerate(fixed_rows):
        row = dict(base)
        for metric in METRIC_NAMES:
            mean, q025, med, q975 = quantile_summary(metrics[metric][:, col])
            row[f"{metric}_mean"] = mean
            row[f"{metric}_q025"] = q025
            row[f"{metric}_median"] = med
            row[f"{metric}_q975"] = q975
        pair_rows.append(row)
    write_csv(output_dir / "pairwise_observed_summary.csv", pair_rows)

    set_ids = sorted({e.set_id for e in entities}, key=numeric_set_sort)
    set_rows: list[dict[str, Any]] = []
    global_iteration_rows = [{"iteration": i + 1} for i in range(n_iterations)]
    global_summaries: dict[str, tuple[float, float, float, float]] = {}
    for metric in METRIC_NAMES:
        global_iter, set_arrays = set_stat_iterations(metrics[metric], pairs)
        global_summaries[metric] = quantile_summary(global_iter)
        for i, value in enumerate(global_iter):
            global_iteration_rows[i][metric] = float(value)
        for set_id in set_ids:
            arr = set_arrays[set_id]
            matching = [e for e in entities if e.set_id == set_id]
            existing = next((r for r in set_rows if r["association_id"] == set_id), None)
            if existing is None:
                existing = {
                    "association_id": set_id,
                    "source_set_id": matching[0].source_set_id,
                    "association_code": matching[0].association_type,
                    "association_group": matching[0].association_group,
                    "raw_material": matching[0].raw_material,
                    "n_artefacts": len(matching),
                    "n_pairwise_links": sum(1 for p in pairs if p.set_id == set_id),
                }
                set_rows.append(existing)
            mean, q025, med, q975 = quantile_summary(arr)
            existing[f"{metric}_mean"] = mean
            existing[f"{metric}_q025"] = q025
            existing[f"{metric}_median"] = med
            existing[f"{metric}_q975"] = q975
    depth_global, depth_sets = depth_set_stat(entities, pairs)
    for row in set_rows:
        row["depth_separation_cm_set_median"] = depth_sets[row["association_id"]]
    write_csv(output_dir / "set_observed_summary.csv", sorted(set_rows, key=lambda r: numeric_set_sort(r["association_id"])))
    write_csv(output_dir / "observed_iteration_summary.csv", global_iteration_rows)

    summary_rows = []
    for metric, vals in global_summaries.items():
        mean, q025, med, q975 = vals
        summary_rows.append({"analysis": analysis_name, "metric": metric, "mean": mean, "q025": q025, "median": med, "q975": q975})
    summary_rows.append({"analysis": analysis_name, "metric": "depth_separation_cm", "mean": "", "q025": "", "median": depth_global, "q975": ""})
    summary_rows.extend([
        {"analysis": analysis_name, "metric": "n_sets", "mean": "", "q025": "", "median": len(set_ids), "q975": ""},
        {"analysis": analysis_name, "metric": "n_artefacts", "mean": "", "q025": "", "median": len(entities), "q975": ""},
        {"analysis": analysis_name, "metric": "n_pairwise_links", "mean": "", "q025": "", "median": len(pairs), "q975": ""},
    ])
    write_csv(output_dir / "analysis_summary.csv", summary_rows)
    return {
        "entities": entities,
        "pairs": pairs,
        "pair_rows": pair_rows,
        "set_rows": set_rows,
        "iteration_metrics": {m: set_stat_iterations(metrics[m], pairs)[0] for m in METRIC_NAMES},
        "depth_global": depth_global,
        "summary_rows": summary_rows,
    }


def _sample_one_coordinate(
    entity: Entity,
    rng: np.random.Generator,
    polygons: dict[str, Polygon],
    intervals: dict[tuple[str, str], Interval],
) -> tuple[float, float, float]:
    if entity.provenance == "measured_total_station":
        assert entity.x is not None and entity.y is not None and entity.z is not None
        return entity.x, entity.y, entity.z
    polygon = polygons[entity.square]
    interval = intervals[(entity.square, entity.spit)]
    u, v, w = rng.random(3)
    xy = polygon.nw + u * (polygon.ne - polygon.nw) + v * (polygon.sw - polygon.nw)
    x, y = float(xy[0]), float(xy[1])
    upper = float(_evaluate_plane(interval.upper, x, y))
    lower = float(_evaluate_plane(interval.lower, x, y))
    if upper < lower:
        raise ValueError(f"Inverted interval at sampled point for {entity.key}")
    z = lower + w * (upper - lower)
    return x, y, z


def _metrics_for_single_coords(coords: list[tuple[float, float, float]], pairs: list[PairDef]) -> dict[str, list[float]]:
    out = {name: [] for name in METRIC_NAMES}
    for pair in pairs:
        xa, ya, za = coords[pair.i]
        xb, yb, zb = coords[pair.j]
        horizontal = math.hypot(xb - xa, yb - ya)
        dz = abs(zb - za)
        out["horizontal_distance_m"].append(horizontal)
        out["vertical_elevation_separation_cm"].append(dz * 100.0)
        out["distance_3d_m"].append(math.sqrt(horizontal * horizontal + dz * dz))
        out["plunge_deg"].append(math.degrees(math.atan2(dz, horizontal)))
    return out


def _global_set_median(values: list[float], pairs: list[PairDef]) -> float:
    grouped: dict[str, list[float]] = defaultdict(list)
    for value, pair in zip(values, pairs):
        grouped[pair.set_id].append(value)
    return float(np.median([np.median(v) for v in grouped.values()]))


def run_randomisation(
    analysis_name: str,
    observed_entities: list[Entity],
    background_entities: list[Entity],
    n_iterations: int,
    seed: int,
    polygons: dict[str, Polygon],
    intervals: dict[tuple[str, str], Interval],
    output_dir: Path,
) -> dict[str, Any]:
    pools: dict[tuple[str, str], list[Entity]] = defaultdict(list)
    for entity in background_entities:
        pools[(entity.square, entity.phase)].append(entity)

    # Sets with no valid same-square/same-phase comparator remain in all
    # descriptive outputs but are excluded from the strict matched null.
    excluded_sets: dict[str, list[str]] = defaultdict(list)
    for entity in observed_entities:
        if len(pools[(entity.square, entity.phase)]) == 0:
            excluded_sets[entity.set_id].append(
                f"no background comparator for square={entity.square};phase={entity.phase};endpoint={entity.art_id}"
            )
    eligible_entities = [e for e in observed_entities if e.set_id not in excluded_sets]
    if not eligible_entities:
        raise ValueError(f"No sets eligible for strict randomisation: {analysis_name}")
    write_csv(
        output_dir / "randomisation_excluded_sets.csv",
        [
            {"association_id": set_id, "exclusion_reason": ";".join(reasons)}
            for set_id, reasons in sorted(excluded_sets.items(), key=lambda item: numeric_set_sort(item[0]))
        ],
        fieldnames=["association_id", "exclusion_reason"],
    )

    pairs = build_pairs(eligible_entities)
    requirements = Counter((e.square, e.phase) for e in eligible_entities)
    pool_summary = []
    for cell, required in sorted(requirements.items()):
        available = len(pools[cell])
        pool_summary.append({"square": cell[0], "phase": cell[1], "required_per_iteration": required, "available_background": available, "sufficient": available >= required})
        if available < required:
            raise ValueError(f"Insufficient null pool for {analysis_name}, cell {cell}: required {required}, available {available}")
    write_csv(output_dir / "null_pool_summary.csv", pool_summary)

    endpoint_by_cell: dict[tuple[str, str], list[int]] = defaultdict(list)
    for idx, entity in enumerate(eligible_entities):
        endpoint_by_cell[(entity.square, entity.phase)].append(idx)

    rng_obs = np.random.default_rng(seed)
    ox, oy, oz = simulate_coordinates(eligible_entities, n_iterations, rng_obs, polygons, intervals)
    observed_metric_arrays = pair_metric_arrays(ox, oy, oz, pairs)
    observed_global = {metric: set_stat_iterations(arr, pairs)[0] for metric, arr in observed_metric_arrays.items()}
    observed_depth, _ = depth_set_stat(eligible_entities, pairs)

    rng = np.random.default_rng(seed + 1000003)

    # Vectorised matched sampling. Each square-phase cell is sampled without
    # replacement within each iteration, while reuse across iterations is allowed.
    bg_measured = np.array([e.provenance == "measured_total_station" for e in background_entities], dtype=bool)
    bg_x = np.array([e.x if e.x is not None else np.nan for e in background_entities], dtype=float)
    bg_y = np.array([e.y if e.y is not None else np.nan for e in background_entities], dtype=float)
    bg_z = np.array([e.z if e.z is not None else np.nan for e in background_entities], dtype=float)
    bg_depth = np.array([e.depth_m for e in background_entities], dtype=float)
    bg_upper = np.zeros((len(background_entities), 3), dtype=float)
    bg_lower = np.zeros((len(background_entities), 3), dtype=float)
    bg_global_index = {id(entity): idx for idx, entity in enumerate(background_entities)}
    pool_indices_by_cell: dict[tuple[str, str], np.ndarray] = {}
    for cell, entities_in_pool in pools.items():
        indices = np.array([bg_global_index[id(e)] for e in entities_in_pool], dtype=int)
        pool_indices_by_cell[cell] = indices
        for idx in indices:
            entity = background_entities[int(idx)]
            if entity.provenance != "measured_total_station":
                interval = intervals[(entity.square, entity.spit)]
                bg_upper[int(idx), :] = interval.upper
                bg_lower[int(idx), :] = interval.lower

    selected_idx = np.empty((n_iterations, len(eligible_entities)), dtype=int)
    for cell, endpoint_indices in endpoint_by_cell.items():
        pool_idx = pool_indices_by_cell[cell]
        k = len(endpoint_indices)
        if k == 1:
            local = rng.integers(0, len(pool_idx), size=(n_iterations, 1))
        else:
            scores = rng.random((n_iterations, len(pool_idx)))
            local = np.argpartition(scores, kth=k - 1, axis=1)[:, :k]
        selected_idx[:, np.array(endpoint_indices, dtype=int)] = pool_idx[local]

    nx = np.empty_like(selected_idx, dtype=float)
    ny = np.empty_like(selected_idx, dtype=float)
    nz = np.empty_like(selected_idx, dtype=float)
    for col, endpoint in enumerate(eligible_entities):
        idx_arr = selected_idx[:, col]
        measured_mask = bg_measured[idx_arr]
        nx[measured_mask, col] = bg_x[idx_arr[measured_mask]]
        ny[measured_mask, col] = bg_y[idx_arr[measured_mask]]
        nz[measured_mask, col] = bg_z[idx_arr[measured_mask]]
        imputed_mask = ~measured_mask
        if np.any(imputed_mask):
            polygon = polygons[endpoint.square]
            uvw = rng.random((int(np.sum(imputed_mask)), 3))
            xy = polygon.nw + uvw[:, [0]] * (polygon.ne - polygon.nw) + uvw[:, [1]] * (polygon.sw - polygon.nw)
            xi, yi = xy[:, 0], xy[:, 1]
            selected_imputed = idx_arr[imputed_mask]
            upper_coeff = bg_upper[selected_imputed]
            lower_coeff = bg_lower[selected_imputed]
            upper_z = upper_coeff[:, 0] + upper_coeff[:, 1] * xi + upper_coeff[:, 2] * yi
            lower_z = lower_coeff[:, 0] + lower_coeff[:, 1] * xi + lower_coeff[:, 2] * yi
            if np.any(upper_z < lower_z - 1e-10):
                raise ValueError(f"Inverted background interval during vectorised sampling for cell {(endpoint.square, endpoint.phase)}")
            zi = lower_z + uvw[:, 2] * (upper_z - lower_z)
            nx[imputed_mask, col] = xi
            ny[imputed_mask, col] = yi
            nz[imputed_mask, col] = zi

    null_metric_arrays = pair_metric_arrays(nx, ny, nz, pairs)
    null_values = {metric: set_stat_iterations(arr, pairs)[0] for metric, arr in null_metric_arrays.items()}
    selected_depth = bg_depth[selected_idx]
    depth_pairs = np.column_stack([
        np.abs(selected_depth[:, pair.i] - selected_depth[:, pair.j]) * 100.0 for pair in pairs
    ])
    null_depth, _ = set_stat_iterations(depth_pairs, pairs)
    selected_counts = Counter({
        "measured_total_station": int(np.sum(bg_measured[selected_idx])),
        "imputed_7mm_sieved": int(np.sum(~bg_measured[selected_idx])),
    })

    iteration_rows = []
    for i in range(n_iterations):
        row = {"iteration": i + 1, "observed_depth_separation_cm": observed_depth, "null_depth_separation_cm": float(null_depth[i])}
        for metric in METRIC_NAMES:
            row[f"observed_{metric}"] = float(observed_global[metric][i])
            row[f"null_{metric}"] = float(null_values[metric][i])
        iteration_rows.append(row)
    write_csv(output_dir / "randomisation_iterations.csv", iteration_rows)

    summary_rows: list[dict[str, Any]] = []
    for metric in METRIC_NAMES:
        obs = observed_global[metric]
        null = null_values[metric]
        summary_rows.append({
            "analysis": analysis_name,
            "metric": metric,
            "eligible_sets": len({e.set_id for e in eligible_entities}),
            "excluded_sets": len(excluded_sets),
            "observed_median": float(np.median(obs)),
            "observed_q025": float(np.quantile(obs, 0.025)),
            "observed_q975": float(np.quantile(obs, 0.975)),
            "null_median": float(np.median(null)),
            "null_q025": float(np.quantile(null, 0.025)),
            "null_q975": float(np.quantile(null, 0.975)),
            "median_null_minus_observed": float(np.median(null - obs)),
            "empirical_p_lower_tail": float((1 + np.sum(null <= obs)) / (n_iterations + 1)),
        })
    summary_rows.append({
        "analysis": analysis_name,
        "metric": "depth_separation_cm",
        "eligible_sets": len({e.set_id for e in eligible_entities}),
        "excluded_sets": len(excluded_sets),
        "observed_median": observed_depth,
        "observed_q025": observed_depth,
        "observed_q975": observed_depth,
        "null_median": float(np.median(null_depth)),
        "null_q025": float(np.quantile(null_depth, 0.025)),
        "null_q975": float(np.quantile(null_depth, 0.975)),
        "median_null_minus_observed": float(np.median(null_depth - observed_depth)),
        "empirical_p_lower_tail": float((1 + np.sum(null_depth <= observed_depth)) / (n_iterations + 1)),
    })
    write_csv(output_dir / "randomisation_summary.csv", summary_rows)
    write_csv(output_dir / "null_selected_coordinate_provenance_counts.csv", [
        {"coordinate_provenance": key, "total_endpoint_selections": value} for key, value in sorted(selected_counts.items())
    ])
    return {
        "summary_rows": summary_rows,
        "observed_global": observed_global,
        "null_values": null_values,
        "observed_depth": observed_depth,
        "null_depth": null_depth,
        "eligible_entities": eligible_entities,
        "excluded_sets": excluded_sets,
        "pairs": pairs,
    }

def raw_material_summary(pair_rows: list[dict[str, Any]], analysis_name: str) -> list[dict[str, Any]]:
    grouped: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for row in pair_rows:
        grouped[row["raw_material"]].append(row)
    output = []
    for material, rows in sorted(grouped.items()):
        art_ids = {r["art_id_a"] for r in rows} | {r["art_id_b"] for r in rows}
        association_ids = {r["association_id"] for r in rows}
        output.append({
            "analysis": analysis_name,
            "raw_material": material,
            "n_artefacts": len(art_ids),
            "n_associations": len(association_ids),
            "n_pairwise_links": len(rows),
            "median_depth_separation_cm": float(np.median([float(r["depth_separation_cm"]) for r in rows])),
            "median_horizontal_distance_m": float(np.median([float(r["horizontal_distance_m_median"]) for r in rows])),
            "median_vertical_elevation_separation_cm": float(np.median([float(r["vertical_elevation_separation_cm_median"]) for r in rows])),
            "median_distance_3d_m": float(np.median([float(r["distance_3d_m_median"]) for r in rows])),
            "median_plunge_deg": float(np.median([float(r["plunge_deg_median"]) for r in rows])),
            "proportion_same_phase": sum(bool(r["same_phase"]) for r in rows) / len(rows),
            "proportion_same_depth_10cm_unit": sum(bool(r["same_depth_10cm_unit"]) for r in rows) / len(rows),
        })
    return output


def validation_row(check: str, passed: bool, observed: Any, expected: Any, severity: str = "hard") -> dict[str, Any]:
    return {"check": check, "status": "PASS" if passed else "FAIL", "severity": severity, "observed": observed, "expected": expected}


def file_manifest(root: Path) -> list[dict[str, Any]]:
    rows = []
    for path in sorted(root.rglob("*")):
        if path.is_file() and path.name not in {"checksums.sha256"}:
            rows.append({"relative_path": path.relative_to(root).as_posix(), "size_bytes": path.stat().st_size, "sha256": sha256(path)})
    return rows
