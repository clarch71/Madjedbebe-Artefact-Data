from __future__ import annotations

import argparse
import json
import math
import shutil
import sys
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

from analysis_core import (
    build_pairs,
    load_associations,
    load_background,
    load_intervals,
    load_json,
    load_measured_coordinates,
    load_metadata,
    load_polygons,
    raw_material_summary,
    run_randomisation,
    sha256,
    simulate_observed,
    validation_row,
    write_csv,
)
from maximum_extent import (
    derive_interval_depth_bounds,
    load_square_datums,
    maximum_extent_observed,
    maximum_extent_randomisation,
    maximum_raw_material_summary,
)

EXPECTED_MATERIALS = {
    "Silcrete": {"artefacts": 29, "associations": 14, "links": 16},
    "Quartzite": {"artefacts": 6, "associations": 3, "links": 3},
    "Dolerite": {"artefacts": 6, "associations": 2, "links": 7},
    "Dark grey quartzite": {"artefacts": 3, "associations": 1, "links": 3},
    "Chert": {"artefacts": 2, "associations": 1, "links": 1},
    "Brown quartzite": {"artefacts": 2, "associations": 1, "links": 1},
    "Oenpelli dolerite": {"artefacts": 2, "associations": 1, "links": 1},
    "Haematite": {"artefacts": 2, "associations": 1, "links": 1},
    "Quartz": {"artefacts": 2, "associations": 1, "links": 1},
    "Sandstone": {"artefacts": 2, "associations": 1, "links": 1},
}


def plot_randomisation(summary_obj, metric: str, title: str, output: Path) -> None:
    observed = np.asarray(summary_obj["observed_global"][metric], dtype=float)
    null = np.asarray(summary_obj["null_values"][metric], dtype=float)
    plt.figure(figsize=(7.2, 4.8))
    plt.hist(null, bins=45, alpha=0.75, label="Matched null")
    plt.axvline(float(np.median(observed)), linewidth=2, label="Observed")
    plt.xlabel(metric.replace("_", " "))
    plt.ylabel("Iterations")
    plt.title(title)
    plt.legend()
    plt.tight_layout()
    output.parent.mkdir(parents=True, exist_ok=True)
    plt.savefig(output, dpi=220)
    plt.close()


def plot_ecdf(rows, field: str, title: str, output: Path) -> None:
    values = np.sort(np.array([float(row[field]) for row in rows], dtype=float))
    y = np.arange(1, len(values) + 1) / len(values)
    plt.figure(figsize=(7.2, 4.8))
    plt.step(values, y, where="post")
    plt.xlabel(field.replace("_", " "))
    plt.ylabel("Empirical cumulative proportion")
    plt.title(title)
    plt.tight_layout()
    output.parent.mkdir(parents=True, exist_ok=True)
    plt.savefig(output, dpi=220)
    plt.close()


def measured_polygon_audit(measured, polygons):
    rows = []
    for entity in sorted(measured.values(), key=lambda item: (item.square, item.spit, item.art_id)):
        polygon = polygons[entity.square]
        east = polygon.ne - polygon.nw
        south = polygon.sw - polygon.nw
        matrix = np.column_stack([east, south])
        uv = np.linalg.solve(matrix, np.array([entity.x, entity.y]) - polygon.nw)
        u, v = float(uv[0]), float(uv[1])
        inside = -1e-10 <= u <= 1.0 + 1e-10 and -1e-10 <= v <= 1.0 + 1e-10
        du = max(0.0, -u, u - 1.0)
        dv = max(0.0, -v, v - 1.0)
        distance = math.hypot(du * float(np.linalg.norm(east)), dv * float(np.linalg.norm(south)))
        rows.append({
            "ArtID_norm": entity.art_id,
            "Square": entity.square,
            "Spit": entity.spit,
            "xnew": entity.x,
            "ynew": entity.y,
            "elevation": entity.z,
            "inside_fitted_polygon": inside,
            "distance_outside_polygon_m": distance,
            "polygon_u": u,
            "polygon_v": v,
            "polygon_quality_flag": polygon.quality_flag,
        })
    return rows


def entity_rows(entities):
    return [{
        "association_id": entity.set_id,
        "source_set_id": entity.source_set_id,
        "association_group": entity.association_group,
        "ArtID": entity.art_id,
        "Square": entity.square,
        "Spit": entity.spit,
        "Raw material": entity.raw_material,
        "Phase": entity.phase,
        "Depth m": entity.depth_m,
        "Depth 10cm": entity.depth_10cm,
        "Coordinate provenance": entity.provenance,
        "xnew": entity.x if entity.x is not None else "",
        "ynew": entity.y if entity.y is not None else "",
        "elevation": entity.z if entity.z is not None else "",
    } for entity in entities]


def standard_maximum_pair_comparison(standard_rows, maximum_rows):
    maximum_by_index = {int(row["pair_index"]): row for row in maximum_rows}
    rows = []
    mapping = {
        "horizontal_distance_m": "maximum_horizontal_distance_m",
        "vertical_elevation_separation_cm": "maximum_vertical_elevation_separation_cm",
        "distance_3d_m": "maximum_distance_3d_m",
        "plunge_deg": "maximum_vertex_plunge_deg",
    }
    for standard in standard_rows:
        maximum = maximum_by_index[int(standard["pair_index"])]
        row = {key: standard[key] for key in [
            "pair_index", "association_id", "source_set_id", "association_code",
            "association_group", "raw_material", "art_id_a", "art_id_b",
            "square_a", "square_b", "spit_a", "spit_b", "phase_a", "phase_b",
            "coordinate_provenance_a", "coordinate_provenance_b",
        ]}
        row["standard_depth_separation_cm"] = standard["depth_separation_cm"]
        row["maximum_stratigraphic_depth_separation_cm"] = maximum["maximum_stratigraphic_depth_separation_cm"]
        row["maximum_minus_standard_metadata_depth_cm"] = (
            float(maximum["maximum_stratigraphic_depth_separation_cm"]) - float(standard["depth_separation_cm"])
        )
        for standard_metric, maximum_metric in mapping.items():
            standard_value = float(standard[f"{standard_metric}_median"])
            maximum_value = float(maximum[maximum_metric])
            row[f"standard_{standard_metric}_median"] = standard_value
            row[maximum_metric] = maximum_value
            row[f"{standard_metric}_upper_bound_increase"] = maximum_value - standard_value
            row[f"{standard_metric}_upper_bound_ratio"] = maximum_value / standard_value if standard_value > 0 else ""
        rows.append(row)
    return rows


def material_counts(entities):
    out = {}
    for material in sorted({e.raw_material for e in entities}):
        subset = [e for e in entities if e.raw_material == material]
        out[material] = {
            "artefacts": len(subset),
            "associations": len({e.set_id for e in subset}),
            "links": len(build_pairs(subset)),
        }
    return out


def main() -> int:
    parser = argparse.ArgumentParser(description="Run the definitive Madjedbebe refit and conjoin analysis")
    parser.add_argument("--config", default="config/analysis_config.json")
    parser.add_argument("--iterations", type=int, default=None, help="Override both imputation and randomisation iterations")
    args = parser.parse_args()

    root = Path(__file__).resolve().parents[1]
    config = load_json(root / args.config)
    n_impute = args.iterations or int(config["coordinate_imputation_iterations"])
    n_random = args.iterations or int(config["randomisation_iterations"])
    seed = int(config["random_seed"])

    output = root / "output"
    if output.exists():
        shutil.rmtree(output)
    for name in [
        "validation",
        "all_material_standard_imputation",
        "all_material_maximum_extent",
        "silcrete_standard_randomisation",
        "silcrete_maximum_extent_randomisation",
        "standard_vs_maximum_comparison",
        "raw_material_descriptive_summary",
        "figures",
    ]:
        (output / name).mkdir(parents=True, exist_ok=True)

    paths = {key: root / value for key, value in config.items() if key.endswith("_file")}
    polygons = load_polygons(paths["square_polygons_file"])
    intervals = load_intervals(paths["vertical_intervals_file"])
    square_datums = load_square_datums(paths["square_surface_datums_file"])
    interval_depth_bounds = derive_interval_depth_bounds(polygons, intervals, square_datums)
    metadata, completion_audit = load_metadata(
        paths["site_square_spit_metadata_file"], intervals,
        paths["square_polygons_file"], paths["square_surface_datums_file"],
    )
    write_csv(
        output / "validation/metadata_completion_audit.csv", completion_audit,
        fieldnames=["square", "spit", "depth_m", "depth_10cm", "phase", "completion_methods", "interval_sampling_model", "interval_quality_flag"],
    )

    measured = load_measured_coordinates(paths["measured_silcrete_coordinates_file"])
    associations = load_associations(paths["association_file"], metadata, measured)
    associated_ids = {entity.art_id for entity in associations}
    background = load_background(
        paths["silcrete_7mm_background_file"], paths["measured_silcrete_coordinates_file"], metadata, associated_ids,
    )
    write_csv(output / "validated_association_artefacts.csv", entity_rows(associations))

    measured_audit = measured_polygon_audit(measured, polygons)
    write_csv(output / "validation/measured_coordinate_polygon_audit.csv", measured_audit)
    outside = [row for row in measured_audit if not row["inside_fitted_polygon"]]

    association_ids = {entity.set_id for entity in associations}
    source_set_ids = {entity.source_set_id for entity in associations}
    silcrete = [entity for entity in associations if entity.raw_material.casefold() == "silcrete"]
    silcrete_ids = {entity.set_id for entity in silcrete}
    material_observed = material_counts(associations)

    validation = [
        validation_row("association artefact count", len(associations) == 56, len(associations), 56),
        validation_row("analytical association count", len(association_ids) == 26, len(association_ids), 26),
        validation_row("source set label count", len(source_set_ids) == 26, len(source_set_ids), 26),
        validation_row("association_type_new is the analytical set key", config.get("analytical_set_key") == "association_type_new", config.get("analytical_set_key"), "association_type_new"),
        validation_row("all rows are refits or conjoins", {e.association_group for e in associations} == {"Refit", "Conjoin"}, sorted({e.association_group for e in associations}), ["Conjoin", "Refit"]),
        validation_row("all association ArtIDs are unique", len(associated_ids) == len(associations), len(associated_ids), len(associations)),
        validation_row("all source set labels map one-to-one to association IDs", len({(e.source_set_id, e.set_id) for e in associations}) == 26, len({(e.source_set_id, e.set_id) for e in associations}), 26),
        validation_row("silcrete artefact count", len(silcrete) == 29, len(silcrete), 29),
        validation_row("silcrete association count", len(silcrete_ids) == 14, len(silcrete_ids), 14),
        validation_row("measured plotted silcrete count", len(measured) == 113, len(measured), 113),
        validation_row("all associated artefacts excluded from null", not ({e.art_id for e in background} & associated_ids), len({e.art_id for e in background} & associated_ids), 0),
        validation_row("silcrete null population count", len(background) == 3069, len(background), 3069),
        validation_row("raw-material composition", material_observed == EXPECTED_MATERIALS, material_observed, EXPECTED_MATERIALS),
        validation_row("all polygons are 1 m2", all(abs(p.area_m2 - 1.0) < 1e-6 for p in polygons.values()), max(abs(p.area_m2 - 1.0) for p in polygons.values()), "<1e-6"),
        validation_row("all intervals usable", all(interval.usable for interval in intervals.values()), sum(not interval.usable for interval in intervals.values()), 0),
        validation_row("all interval depth bounds ordered", all(lower >= upper for upper, lower in interval_depth_bounds.values()), sum(lower < upper for upper, lower in interval_depth_bounds.values()), 0),
        validation_row("maximum-extent analysis enabled", config.get("maximum_extent_analysis_enabled") is True, config.get("maximum_extent_analysis_enabled"), True),
        validation_row("age analysis disabled", config.get("age_analysis_enabled") is False, config.get("age_analysis_enabled"), False),
        validation_row("additional slope correction disabled", config.get("additional_slope_correction_enabled") is False, config.get("additional_slope_correction_enabled"), False),
        validation_row("measured points outside fitted polygon retained and audited", True, len(outside), "reported; coordinates unchanged", "informational"),
    ]

    standard_observed = simulate_observed(
        "all_material_standard_imputation", associations, n_impute, seed + 11, polygons, intervals,
        output / "all_material_standard_imputation",
    )
    maximum_observed = maximum_extent_observed(
        "all_material_maximum_extent", associations, polygons, intervals, interval_depth_bounds, square_datums,
        output / "all_material_maximum_extent",
    )
    validation.extend([
        validation_row("standard pairwise link count", len(standard_observed["pairs"]) == 35, len(standard_observed["pairs"]), 35),
        validation_row("maximum-extent pairwise link count", len(maximum_observed["pairs"]) == 35, len(maximum_observed["pairs"]), 35),
    ])

    standard_randomisation = run_randomisation(
        "silcrete_standard_imputation_randomisation", silcrete, background, n_random, seed + 101,
        polygons, intervals, output / "silcrete_standard_randomisation",
    )
    maximum_randomisation = maximum_extent_randomisation(
        "silcrete_maximum_extent_randomisation", silcrete, background, n_random, seed + 101,
        polygons, intervals, interval_depth_bounds, square_datums,
        output / "silcrete_maximum_extent_randomisation",
    )
    silcrete_pair_count = len(build_pairs(silcrete))
    validation.extend([
        validation_row("silcrete pairwise link count", silcrete_pair_count == 16, silcrete_pair_count, 16),
        validation_row("standard strict-null eligible association count", len({e.set_id for e in standard_randomisation["eligible_entities"]}) == 13, len({e.set_id for e in standard_randomisation["eligible_entities"]}), 13),
        validation_row("maximum strict-null eligible association count", len({e.set_id for e in maximum_randomisation["eligible_entities"]}) == 13, len({e.set_id for e in maximum_randomisation["eligible_entities"]}), 13),
        validation_row("standard strict-null excluded associations", set(standard_randomisation["excluded_sets"]) == {"Refit A"}, sorted(standard_randomisation["excluded_sets"]), ["Refit A"]),
        validation_row("maximum strict-null excluded associations", set(maximum_randomisation["excluded_sets"]) == {"Refit A"}, sorted(maximum_randomisation["excluded_sets"]), ["Refit A"]),
    ])

    comparison_rows = standard_maximum_pair_comparison(standard_observed["pair_rows"], maximum_observed["pair_rows"])
    write_csv(output / "standard_vs_maximum_comparison/pairwise_standard_vs_maximum.csv", comparison_rows)
    write_csv(output / "raw_material_descriptive_summary/standard_imputation_by_raw_material.csv", raw_material_summary(standard_observed["pair_rows"], "all_material_standard_imputation"))
    write_csv(output / "raw_material_descriptive_summary/maximum_extent_by_raw_material.csv", maximum_raw_material_summary(maximum_observed["pair_rows"], "all_material_maximum_extent"))

    upper_horizontal_ok = all(float(r["maximum_horizontal_distance_m"]) + 1e-10 >= float(r["standard_horizontal_distance_m_median"]) for r in comparison_rows)
    upper_vertical_ok = all(float(r["maximum_vertical_elevation_separation_cm"]) + 1e-8 >= float(r["standard_vertical_elevation_separation_cm_median"]) for r in comparison_rows)
    upper_3d_ok = all(float(r["maximum_distance_3d_m"]) + 1e-10 >= float(r["standard_distance_3d_m_median"]) for r in comparison_rows)
    validation.extend([
        validation_row("maximum horizontal values bound standard medians", upper_horizontal_ok, upper_horizontal_ok, True),
        validation_row("maximum elevation values bound standard medians", upper_vertical_ok, upper_vertical_ok, True),
        validation_row("maximum 3D values bound standard medians", upper_3d_ok, upper_3d_ok, True),
    ])

    plot_ecdf(standard_observed["pair_rows"], "depth_separation_cm", "Observed stratigraphic depth separation", output / "figures/standard_observed_depth_ecdf.png")
    plot_ecdf(standard_observed["pair_rows"], "horizontal_distance_m_median", "Observed horizontal separation: standard imputation", output / "figures/standard_observed_horizontal_ecdf.png")
    plot_ecdf(maximum_observed["pair_rows"], "maximum_horizontal_distance_m", "Observed horizontal separation: maximum extent", output / "figures/maximum_extent_horizontal_ecdf.png")
    plot_randomisation(standard_randomisation, "horizontal_distance_m", "Silcrete horizontal randomisation: standard imputation", output / "figures/silcrete_standard_horizontal_randomisation.png")
    plot_randomisation(standard_randomisation, "vertical_elevation_separation_cm", "Silcrete elevation randomisation: standard imputation", output / "figures/silcrete_standard_vertical_randomisation.png")
    plot_randomisation(maximum_randomisation, "maximum_horizontal_distance_m", "Silcrete horizontal randomisation: maximum extent", output / "figures/silcrete_maximum_horizontal_randomisation.png")
    plot_randomisation(maximum_randomisation, "maximum_stratigraphic_depth_separation_cm", "Silcrete stratigraphic-depth randomisation: maximum extent", output / "figures/silcrete_maximum_depth_randomisation.png")

    write_csv(output / "validation/validation_report.csv", validation)
    hard_failures = [row for row in validation if row["severity"] == "hard" and row["status"] == "FAIL"]
    if hard_failures:
        raise RuntimeError(f"Hard validation failures: {hard_failures}")

    summary_lines = [
        "Madjedbebe refit and conjoin analysis workpackage v1.4.0",
        f"Coordinate imputation iterations: {n_impute}",
        f"Matched randomisation iterations per model: {n_random}",
        f"All materials: {len(associations)} artefacts, {len(association_ids)} associations, {len(standard_observed['pairs'])} pairwise links",
        f"Silcrete inferential subset: {len(silcrete)} artefacts, {len(silcrete_ids)} associations, {silcrete_pair_count} pairwise links",
        f"Silcrete null population: {len(background)} artefacts",
        "Standard model: repeated uniform coordinate imputation within validated square polygons and vertical intervals.",
        "Maximum-extent model: exact upper-bound separation using complete square polygons and vertical interval supports for unmeasured artefacts.",
        "All raw materials are included in observed descriptive analyses; formal matched randomisation is restricted to silcrete.",
        "Depth m, Depth 10cm and Phase are authoritative metadata. No age analysis, phase reassignment or additional slope correction is performed.",
        f"Hard validation failures: {len(hard_failures)}",
    ]
    (output / "run_summary.txt").write_text("\n".join(summary_lines) + "\n", encoding="utf-8")

    run_metadata = {
        "workpackage_version": config["workpackage_version"],
        "python_version": sys.version,
        "coordinate_imputation_iterations": n_impute,
        "randomisation_iterations_per_model": n_random,
        "random_seed": seed,
        "models": ["standard_coordinate_imputation", "maximum_extent_upper_bound"],
        "analytical_set_key": config["analytical_set_key"],
        "input_sha256": {key: sha256(path) for key, path in paths.items()},
    }
    (output / "run_metadata.json").write_text(json.dumps(run_metadata, indent=2), encoding="utf-8")
    print("Analysis completed successfully.")
    print(output / "run_summary.txt")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
