from __future__ import annotations

import csv
import math
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any

import numpy as np

from analysis_core import (
    Entity,
    Interval,
    PairDef,
    Polygon,
    build_pairs,
    fixed_pair_metadata,
    numeric_set_sort,
    norm_square,
    norm_spit,
    read_csv,
    require_columns,
    write_csv,
)

MAXIMUM_METRIC_NAMES = [
    "maximum_horizontal_distance_m",
    "maximum_stratigraphic_depth_separation_cm",
    "maximum_vertical_elevation_separation_cm",
    "maximum_distance_3d_m",
    "maximum_vertex_plunge_deg",
]


def derive_interval_depth_bounds(
    polygons: dict[str, Polygon],
    intervals: dict[tuple[str, str], Interval],
    square_datums: dict[str, tuple[float, float, float]],
) -> dict[tuple[str, str], tuple[float, float]]:
    """Derive full topography-relative depth supports from validated planes.

    The shallow bound is the minimum depth of the upper interval surface below the
    fitted square datum across the four square vertices. The deep bound is the
    maximum depth of the lower interval surface across the same vertices.
    """
    out: dict[tuple[str, str], tuple[float, float]] = {}
    for key, interval in intervals.items():
        polygon = polygons[interval.square]
        xy = polygon_vertices(polygon)
        datum = square_datums[interval.square]
        datum_z = np.asarray(_eval_plane(datum, xy[:, 0], xy[:, 1]), dtype=float)
        upper_z = np.asarray(_eval_plane(interval.upper, xy[:, 0], xy[:, 1]), dtype=float)
        lower_z = np.asarray(_eval_plane(interval.lower, xy[:, 0], xy[:, 1]), dtype=float)
        upper_depth = float(np.min(datum_z - upper_z))
        lower_depth = float(np.max(datum_z - lower_z))
        if lower_depth < upper_depth - 1e-10:
            raise ValueError(f"Inverted derived stratigraphic interval depth bounds for {key}: {(upper_depth, lower_depth)}")
        out[key] = (upper_depth, lower_depth)
    return out


def load_square_datums(path: Path) -> dict[str, tuple[float, float, float]]:
    rows = read_csv(path)
    require_columns(
        rows,
        ["square", "datum_plane_a_intercept", "datum_plane_b_Xnew", "datum_plane_c_Ynew"],
        "square surface datums",
    )
    return {
        norm_square(row["square"]): (
            float(row["datum_plane_a_intercept"]),
            float(row["datum_plane_b_Xnew"]),
            float(row["datum_plane_c_Ynew"]),
        )
        for row in rows
    }


def _eval_plane(coeffs: tuple[float, float, float], x: np.ndarray | float, y: np.ndarray | float) -> np.ndarray | float:
    a, b, c = coeffs
    return a + b * x + c * y


def polygon_vertices(polygon: Polygon) -> np.ndarray:
    se = polygon.ne + polygon.sw - polygon.nw
    return np.vstack([polygon.nw, polygon.ne, se, polygon.sw])


def entity_support_vertices(
    entity: Entity,
    polygons: dict[str, Polygon],
    intervals: dict[tuple[str, str], Interval],
) -> np.ndarray:
    """Return compatible 3-D support vertices for the maximum-extent model.

    Measured plotted artefacts have a one-point support, repeated to eight rows for
    vectorisation. Unmeasured artefacts are represented by the four square vertices
    evaluated on the upper and lower validated interval planes.
    """
    if entity.provenance == "measured_total_station":
        if entity.x is None or entity.y is None or entity.z is None:
            raise ValueError(f"Measured entity lacks coordinates: {entity.art_id}")
        point = np.array([[entity.x, entity.y, entity.z]], dtype=float)
        return np.repeat(point, 8, axis=0)
    polygon = polygons.get(entity.square)
    interval = intervals.get((entity.square, entity.spit))
    if polygon is None:
        raise ValueError(f"No polygon for maximum-extent entity {entity.art_id} in {entity.square}")
    if interval is None or not interval.usable:
        raise ValueError(f"No usable interval for maximum-extent entity {entity.art_id} at {(entity.square, entity.spit)}")
    xy = polygon_vertices(polygon)
    upper = np.asarray(_eval_plane(interval.upper, xy[:, 0], xy[:, 1]), dtype=float)
    lower = np.asarray(_eval_plane(interval.lower, xy[:, 0], xy[:, 1]), dtype=float)
    if np.any(upper < lower - 1e-10):
        raise ValueError(f"Inverted maximum-extent interval at polygon vertices for {entity.key}")
    return np.vstack([
        np.column_stack([xy, upper]),
        np.column_stack([xy, lower]),
    ])


def entity_depth_support(
    entity: Entity,
    interval_depth_bounds: dict[tuple[str, str], tuple[float, float]],
    square_datums: dict[str, tuple[float, float, float]],
) -> np.ndarray:
    """Return topography-relative depth support in metres below the square datum.

    For measured plotted artefacts the support is their exact measured depth below
    the fitted square surface datum. For unmeasured artefacts the support is the full
    upper-to-lower square-spit depth interval.
    """
    if entity.provenance == "measured_total_station":
        if entity.x is None or entity.y is None or entity.z is None:
            raise ValueError(f"Measured entity lacks coordinates: {entity.art_id}")
        datum = square_datums[entity.square]
        surface_z = float(_eval_plane(datum, entity.x, entity.y))
        depth = surface_z - entity.z
        return np.array([depth, depth], dtype=float)
    bounds = interval_depth_bounds.get((entity.square, entity.spit))
    if bounds is None:
        raise ValueError(f"No depth interval bounds for {entity.key}")
    return np.array(bounds, dtype=float)


def prepare_support_arrays(
    entities: list[Entity],
    polygons: dict[str, Polygon],
    intervals: dict[tuple[str, str], Interval],
    interval_depth_bounds: dict[tuple[str, str], tuple[float, float]],
    square_datums: dict[str, tuple[float, float, float]],
) -> tuple[np.ndarray, np.ndarray]:
    vertices = np.stack([entity_support_vertices(e, polygons, intervals) for e in entities], axis=0)
    depths = np.stack([entity_depth_support(e, interval_depth_bounds, square_datums) for e in entities], axis=0)
    return vertices, depths


def maximum_pair_arrays(
    vertices: np.ndarray,
    depths: np.ndarray,
    pairs: list[PairDef],
    selected_idx: np.ndarray | None = None,
) -> dict[str, np.ndarray]:
    """Calculate maximum-compatible pair metrics.

    If selected_idx is None, vertices/depths represent the observed endpoint list and
    one deterministic row is returned. Otherwise selected_idx has shape
    (iterations, endpoints) and indexes a background support population.
    """
    if selected_idx is None:
        selected_idx = np.arange(vertices.shape[0], dtype=int)[None, :]
    n_iterations = selected_idx.shape[0]
    out = {name: np.empty((n_iterations, len(pairs)), dtype=float) for name in MAXIMUM_METRIC_NAMES}
    for col, pair in enumerate(pairs):
        ia = selected_idx[:, pair.i]
        ib = selected_idx[:, pair.j]
        a = vertices[ia]  # iterations x 8 x 3
        b = vertices[ib]
        diff = b[:, None, :, :] - a[:, :, None, :]
        horizontal = np.sqrt(diff[..., 0] ** 2 + diff[..., 1] ** 2)
        vertical = np.abs(diff[..., 2])
        distance3d = np.sqrt(horizontal ** 2 + vertical ** 2)
        plunge = np.degrees(np.arctan2(vertical, horizontal))
        out["maximum_horizontal_distance_m"][:, col] = np.max(horizontal, axis=(1, 2))
        out["maximum_vertical_elevation_separation_cm"][:, col] = np.max(vertical, axis=(1, 2)) * 100.0
        out["maximum_distance_3d_m"][:, col] = np.max(distance3d, axis=(1, 2))
        out["maximum_vertex_plunge_deg"][:, col] = np.max(plunge, axis=(1, 2))

        da = depths[ia]
        db = depths[ib]
        depth_diff = np.abs(db[:, None, :] - da[:, :, None])
        out["maximum_stratigraphic_depth_separation_cm"][:, col] = np.max(depth_diff, axis=(1, 2)) * 100.0
    return out


def _set_stat(metric_array: np.ndarray, pairs: list[PairDef]) -> tuple[np.ndarray, dict[str, np.ndarray]]:
    by_set: dict[str, list[int]] = defaultdict(list)
    for col, pair in enumerate(pairs):
        by_set[pair.set_id].append(col)
    set_arrays = {set_id: np.median(metric_array[:, cols], axis=1) for set_id, cols in by_set.items()}
    matrix = np.column_stack([set_arrays[s] for s in sorted(set_arrays, key=numeric_set_sort)])
    return np.median(matrix, axis=1), set_arrays


def _summary(values: np.ndarray) -> tuple[float, float, float, float]:
    return (
        float(np.mean(values)),
        float(np.quantile(values, 0.025)),
        float(np.quantile(values, 0.5)),
        float(np.quantile(values, 0.975)),
    )


def maximum_extent_observed(
    analysis_name: str,
    entities: list[Entity],
    polygons: dict[str, Polygon],
    intervals: dict[tuple[str, str], Interval],
    interval_depth_bounds: dict[tuple[str, str], tuple[float, float]],
    square_datums: dict[str, tuple[float, float, float]],
    output_dir: Path,
) -> dict[str, Any]:
    pairs = build_pairs(entities)
    vertices, depths = prepare_support_arrays(entities, polygons, intervals, interval_depth_bounds, square_datums)
    metrics = maximum_pair_arrays(vertices, depths, pairs)
    fixed = fixed_pair_metadata(entities, pairs)
    pair_rows: list[dict[str, Any]] = []
    for col, base in enumerate(fixed):
        row = dict(base)
        for metric in MAXIMUM_METRIC_NAMES:
            row[metric] = float(metrics[metric][0, col])
        pair_rows.append(row)
    write_csv(output_dir / "pairwise_maximum_extent_summary.csv", pair_rows)

    set_rows: list[dict[str, Any]] = []
    global_values: dict[str, float] = {}
    set_arrays_by_metric: dict[str, dict[str, np.ndarray]] = {}
    for metric in MAXIMUM_METRIC_NAMES:
        global_arr, set_arrays = _set_stat(metrics[metric], pairs)
        global_values[metric] = float(global_arr[0])
        set_arrays_by_metric[metric] = set_arrays
    for set_id in sorted({e.set_id for e in entities}, key=numeric_set_sort):
        members = [e for e in entities if e.set_id == set_id]
        row = {
            "association_id": set_id,
            "source_set_id": members[0].source_set_id,
            "association_code": members[0].association_type,
            "association_group": members[0].association_group,
            "raw_material": members[0].raw_material,
            "n_artefacts": len(members),
            "n_pairwise_links": sum(1 for p in pairs if p.set_id == set_id),
        }
        for metric in MAXIMUM_METRIC_NAMES:
            row[f"{metric}_set_median"] = float(set_arrays_by_metric[metric][set_id][0])
        set_rows.append(row)
    write_csv(output_dir / "set_maximum_extent_summary.csv", set_rows)
    summary_rows = [
        {"analysis": analysis_name, "metric": metric, "value": value}
        for metric, value in global_values.items()
    ]
    summary_rows.extend([
        {"analysis": analysis_name, "metric": "n_sets", "value": len({e.set_id for e in entities})},
        {"analysis": analysis_name, "metric": "n_artefacts", "value": len(entities)},
        {"analysis": analysis_name, "metric": "n_pairwise_links", "value": len(pairs)},
    ])
    write_csv(output_dir / "analysis_summary.csv", summary_rows)
    return {
        "pairs": pairs,
        "pair_rows": pair_rows,
        "set_rows": set_rows,
        "global_values": global_values,
        "metric_arrays": metrics,
    }


def _matched_selection_indices(
    observed_entities: list[Entity],
    background_entities: list[Entity],
    n_iterations: int,
    seed: int,
    output_dir: Path,
) -> tuple[list[Entity], list[PairDef], dict[str, list[str]], np.ndarray]:
    pools: dict[tuple[str, str], list[int]] = defaultdict(list)
    for idx, entity in enumerate(background_entities):
        pools[(entity.square, entity.phase)].append(idx)
    excluded: dict[str, list[str]] = defaultdict(list)
    for entity in observed_entities:
        if len(pools[(entity.square, entity.phase)]) == 0:
            excluded[entity.set_id].append(
                f"no background comparator for square={entity.square};phase={entity.phase};endpoint={entity.art_id}"
            )
    eligible = [e for e in observed_entities if e.set_id not in excluded]
    if not eligible:
        raise ValueError("No sets eligible for maximum-extent randomisation")
    write_csv(
        output_dir / "randomisation_excluded_sets.csv",
        [{"association_id": s, "exclusion_reason": ";".join(r)} for s, r in sorted(excluded.items(), key=lambda x: numeric_set_sort(x[0]))],
        fieldnames=["association_id", "exclusion_reason"],
    )
    requirements = Counter((e.square, e.phase) for e in eligible)
    pool_rows = []
    for cell, required in sorted(requirements.items()):
        available = len(pools[cell])
        pool_rows.append({"square": cell[0], "phase": cell[1], "required_per_iteration": required, "available_background": available, "sufficient": available >= required})
        if available < required:
            raise ValueError(f"Insufficient maximum-extent null pool for {cell}: required {required}, available {available}")
    write_csv(output_dir / "null_pool_summary.csv", pool_rows)

    endpoint_by_cell: dict[tuple[str, str], list[int]] = defaultdict(list)
    for idx, entity in enumerate(eligible):
        endpoint_by_cell[(entity.square, entity.phase)].append(idx)
    rng = np.random.default_rng(seed + 1000003)
    selected = np.empty((n_iterations, len(eligible)), dtype=int)
    for cell, endpoint_cols in endpoint_by_cell.items():
        pool_idx = np.asarray(pools[cell], dtype=int)
        k = len(endpoint_cols)
        if k == 1:
            local = rng.integers(0, len(pool_idx), size=(n_iterations, 1))
        else:
            scores = rng.random((n_iterations, len(pool_idx)))
            local = np.argpartition(scores, kth=k - 1, axis=1)[:, :k]
        selected[:, np.asarray(endpoint_cols, dtype=int)] = pool_idx[local]
    return eligible, build_pairs(eligible), excluded, selected


def maximum_extent_randomisation(
    analysis_name: str,
    observed_entities: list[Entity],
    background_entities: list[Entity],
    n_iterations: int,
    seed: int,
    polygons: dict[str, Polygon],
    intervals: dict[tuple[str, str], Interval],
    interval_depth_bounds: dict[tuple[str, str], tuple[float, float]],
    square_datums: dict[str, tuple[float, float, float]],
    output_dir: Path,
) -> dict[str, Any]:
    eligible, pairs, excluded, selected = _matched_selection_indices(
        observed_entities, background_entities, n_iterations, seed, output_dir
    )
    obs_vertices, obs_depths = prepare_support_arrays(eligible, polygons, intervals, interval_depth_bounds, square_datums)
    bg_vertices, bg_depths = prepare_support_arrays(background_entities, polygons, intervals, interval_depth_bounds, square_datums)
    observed_pair = maximum_pair_arrays(obs_vertices, obs_depths, pairs)
    null_pair = maximum_pair_arrays(bg_vertices, bg_depths, pairs, selected_idx=selected)

    observed_global = {m: _set_stat(observed_pair[m], pairs)[0] for m in MAXIMUM_METRIC_NAMES}
    null_global = {m: _set_stat(null_pair[m], pairs)[0] for m in MAXIMUM_METRIC_NAMES}
    rows: list[dict[str, Any]] = []
    for i in range(n_iterations):
        row: dict[str, Any] = {"iteration": i + 1}
        for metric in MAXIMUM_METRIC_NAMES:
            row[f"observed_{metric}"] = float(observed_global[metric][0])
            row[f"null_{metric}"] = float(null_global[metric][i])
        rows.append(row)
    write_csv(output_dir / "randomisation_iterations.csv", rows)

    summaries = []
    for metric in MAXIMUM_METRIC_NAMES:
        obs = float(observed_global[metric][0])
        null = null_global[metric]
        summaries.append({
            "analysis": analysis_name,
            "metric": metric,
            "eligible_sets": len({e.set_id for e in eligible}),
            "excluded_sets": len(excluded),
            "observed_value": obs,
            "null_median": float(np.median(null)),
            "null_q025": float(np.quantile(null, 0.025)),
            "null_q975": float(np.quantile(null, 0.975)),
            "median_null_minus_observed": float(np.median(null - obs)),
            "empirical_p_lower_tail": float((1 + np.sum(null <= obs)) / (n_iterations + 1)),
        })
    write_csv(output_dir / "randomisation_summary.csv", summaries)

    counts = Counter(background_entities[int(i)].provenance for i in selected.ravel())
    write_csv(output_dir / "null_selected_coordinate_provenance_counts.csv", [
        {"coordinate_provenance": key, "total_endpoint_selections": value}
        for key, value in sorted(counts.items())
    ])
    return {
        "summary_rows": summaries,
        "observed_global": observed_global,
        "null_values": null_global,
        "eligible_entities": eligible,
        "excluded_sets": excluded,
        "pairs": pairs,
    }


def maximum_raw_material_summary(pair_rows: list[dict[str, Any]], analysis_name: str) -> list[dict[str, Any]]:
    grouped: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for row in pair_rows:
        grouped[row["raw_material"]].append(row)
    out: list[dict[str, Any]] = []
    for material, rows in sorted(grouped.items()):
        art_ids = {r["art_id_a"] for r in rows} | {r["art_id_b"] for r in rows}
        association_ids = {r["association_id"] for r in rows}
        record: dict[str, Any] = {
            "analysis": analysis_name,
            "raw_material": material,
            "n_artefacts": len(art_ids),
            "n_associations": len(association_ids),
            "n_pairwise_links": len(rows),
        }
        for metric in MAXIMUM_METRIC_NAMES:
            record[f"median_{metric}"] = float(np.median([float(r[metric]) for r in rows]))
        record["proportion_same_phase"] = sum(bool(r["same_phase"]) for r in rows) / len(rows)
        record["proportion_same_depth_10cm_unit"] = sum(bool(r["same_depth_10cm_unit"]) for r in rows) / len(rows)
        out.append(record)
    return out
