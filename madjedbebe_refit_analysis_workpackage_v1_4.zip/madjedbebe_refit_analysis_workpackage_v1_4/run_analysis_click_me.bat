@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel%==0 (
  py -3 -m pip install -r requirements.txt
  if errorlevel 1 exit /b 1
  py -3 scripts\run_analysis.py
  if errorlevel 1 exit /b 1
  py -3 -m pytest -q
  exit /b %errorlevel%
)
python -m pip install -r requirements.txt
if errorlevel 1 exit /b 1
python scripts\run_analysis.py
if errorlevel 1 exit /b 1
python -m pytest -q
exit /b %errorlevel%
