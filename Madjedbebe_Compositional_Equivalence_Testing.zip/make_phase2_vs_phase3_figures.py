#!/usr/bin/env python3
from __future__ import annotations

from pathlib import Path
from typing import List, Tuple, Dict
import argparse
from textwrap import dedent

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap
from matplotlib.gridspec import GridSpec, GridSpecFromSubplotSpec
from sklearn.decomposition import PCA
from sklearn.metrics import pairwise_distances


# Actual trench footprint shown top-to-bottom as requested: B at top, E at bottom.
PLOT_ROW_ORDER = ["E", "D", "C", "B"]

DISPLAY_LABELS = {
    "Quartzite": "Quartzite",
    "Silcrete": "Silcrete",
    "Brown Quartzite": "Brown quartzite",
    "Dark Grey Quartzite": "Dark grey quartzite",
    "Quartzite with Purple Stripes": "Quartzite with purple stripes",
    "Quartzite with Pink/Red Spots": "Quartzite with pink/red spots",
    "Quartz": "Quartz",
    "Crystal Quartz": "Crystal quartz",
    "Sandstone": "Sandstone",
    "Fine Quartzite": "Fine quartzite",
    "Green Weathered Volcanic": "Green weathered volcanic",
    "Oenpelli Dolerite": "Oenpelli dolerite",
    "Basalt": "Basalt",
    "Volcanic": "Volcanic",
    "Chert": "Chert",
    "Buff FGS": "Buff FGS",
    "Gerowie Tuff": "Gerowie Tuff",
    "Glass": "Glass",
}

ABBR_LABELS = {
    "Quartzite": "Quartzite",
    "Silcrete": "Silcrete",
    "Brown Quartzite": "Brown\nQuartzite",
    "Dark Grey Quartzite": "Dk Grey\nQuartzite",
    "Quartzite with Purple Stripes": "Quartzite\n(Purple)",
    "Quartzite with Pink/Red Spots": "Quartzite\n(Pink/Red)",
    "Quartz": "Qtz",
    "Crystal Quartz": "Crystal\nQtz",
    "Sandstone": "Sandst.",
    "Fine Quartzite": "Fine\nQuartzite",
    "Green Weathered Volcanic": "GW\nVolc.",
    "Oenpelli Dolerite": "Oenpelli\nDolerite",
    "Basalt": "Basalt",
    "Volcanic": "Volcanic",
    "Chert": "Chert",
    "Buff FGS": "Buff\nFGS",
    "Gerowie Tuff": "Gerowie\nTuff",
    "Glass": "Glass",
    "Other": "Other",
}

# User-specified standard palette for manuscript-wide consistency.
BASE_MATERIAL_COLORS = {
    "Quartz": "#1f77b4",
    "Crystal Quartz": "#ff7f0e",
    "Quartzite": "#2ca02c",
    "Fine Quartzite": "#d62728",
    "Silcrete": "#9467bd",
    "Chert": "#8c564b",
    "Volcanic": "#e377c2",
    "Oenpelli Dolerite": "#7f7f7f",
    "Gerowie Tuff": "#bcbd22",
    "Brown Quartzite": "#8c510a",
    "Dark Grey Quartzite": "#252525",
    "Quartzite with Purple Stripes": "#542788",
    "Quartzite with Pink/Red Spots": "#b2182b",
    "Sandstone": "#1b9e77",
    "Green Weathered Volcanic": "#006d2c",
    "Basalt": "#000000",
    "Buff FGS": "#a6761d",
}
NO_DATA_COLOR = "#d3d3d3"
OTHER_COLOR = "#c7c7c7"

FALLBACK_MATERIAL_COLORS = [
    "#17becf",
    "#e41a1c",
    "#377eb8",
    "#4daf4a",
    "#984ea3",
    "#ff7f00",
    "#ffff33",
    "#a65628",
    "#f781bf",
    "#999999",
    "#66c2a5",
    "#fc8d62",
    "#8da0cb",
    "#e78ac3",
    "#a6d854",
    "#ffd92f",
    "#e5c494",
    "#b3b3b3",
]


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Generate Phase 2 vs Phase 3 figures and SI-ready result tables from the Madjedbebe dataset.")
    p.add_argument("--input", default="madjedbebe_final_aggregated_dataset.csv")
    p.add_argument("--output-dir", default="phase2_vs_phase3_results")
    p.add_argument("--n-perm", type=int, default=4999)
    return p.parse_args()


def load_and_prepare(path: str | Path) -> Tuple[pd.DataFrame, List[str]]:
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(f"Could not find input file: {path}")

    if path.suffix.lower() == ".csv":
        df = pd.read_csv(path)
    elif path.suffix.lower() in {".xlsx", ".xls"}:
        df = pd.read_excel(path)
    else:
        raise ValueError("Input must be .csv, .xlsx, or .xls")

    if "Row" not in df.columns:
        df["Row"] = df["Square"].astype(str).str.extract(r"([A-Z])")
    if "Column" not in df.columns:
        df["Column"] = df["Square"].astype(str).str.extract(r"(\d+)").astype(float)
    df["Column"] = df["Column"].astype(int)

    sector_fill = pd.Series(np.where(df["Column"] <= 3, "back", "front"), index=df.index)
    if "Sector" not in df.columns:
        df["Sector"] = sector_fill
    else:
        df["Sector"] = df["Sector"].where(df["Sector"].notna(), sector_fill)

    df["Depth 10cm"] = df["Depth 10cm"].astype(float)
    df["Phase"] = df["Phase"].astype(float)

    group_cols = ["Square", "Depth 10cm"]
    meta_cols = ["Row", "Column", "Sector", "Phase"]
    candidate_materials = [
        c for c in df.columns
        if c not in group_cols + meta_cols + ["Total_artefacts"]
    ]

    agg_dict = {c: "sum" for c in candidate_materials}
    for c in meta_cols:
        agg_dict[c] = "first"

    df = df.groupby(group_cols, as_index=False).agg(agg_dict)
    df["Total_artefacts"] = df[candidate_materials].sum(axis=1)

    df = df[df["Phase"].isin([2.0, 3.0])].copy()
    materials = [c for c in candidate_materials if pd.to_numeric(df[c], errors="coerce").fillna(0).sum() > 0]
    df = df[df["Total_artefacts"] > 0].copy()

    return df, materials


def get_material_color_map(materials: List[str]) -> Dict[str, str]:
    out: Dict[str, str] = {}
    used = {c.lower() for c in BASE_MATERIAL_COLORS.values()}
    fallback = [c for c in FALLBACK_MATERIAL_COLORS if c.lower() not in used]
    fallback_idx = 0
    for m in materials:
        if m in BASE_MATERIAL_COLORS:
            out[m] = BASE_MATERIAL_COLORS[m]
        else:
            if fallback_idx >= len(fallback):
                raise ValueError("Not enough unique fallback colours defined for the raw-material categories.")
            out[m] = fallback[fallback_idx]
            fallback_idx += 1
    out["Other"] = OTHER_COLOR
    return out


def hellinger_transform(df: pd.DataFrame, materials: List[str]) -> np.ndarray:
    counts = df[materials].to_numpy(dtype=float)
    row_sums = counts.sum(axis=1, keepdims=True)
    props = np.divide(counts, row_sums, out=np.zeros_like(counts), where=row_sums > 0)
    return np.sqrt(props)


def pooled_phase_proportions(df: pd.DataFrame, materials: List[str]) -> pd.DataFrame:
    pooled = df.groupby("Phase")[materials].sum().sort_index()
    pooled = pooled.div(pooled.sum(axis=1), axis=0).fillna(0)
    return pooled


def prepare_distance_lists(df: pd.DataFrame, materials: List[str]) -> Tuple[List[float], List[float], List[float]]:
    X = hellinger_transform(df, materials)
    D = pairwise_distances(X, metric="euclidean")
    phases = df["Phase"].to_numpy()

    within2: List[float] = []
    within3: List[float] = []
    between: List[float] = []
    n = len(df)
    for i in range(n):
        for j in range(i + 1, n):
            if phases[i] == 2.0 and phases[j] == 2.0:
                within2.append(float(D[i, j]))
            elif phases[i] == 3.0 and phases[j] == 3.0:
                within3.append(float(D[i, j]))
            elif phases[i] != phases[j]:
                between.append(float(D[i, j]))

    return within2, within3, between


def g_test(table: np.ndarray) -> float:
    arr = np.asarray(table, dtype=float)
    total = arr.sum()
    row_sums = arr.sum(axis=1, keepdims=True)
    col_sums = arr.sum(axis=0, keepdims=True)
    expected = row_sums @ col_sums / total
    mask = arr > 0
    G = 2 * np.sum(arr[mask] * np.log(arr[mask] / expected[mask]))
    return float(G)


def permanova_F(X: np.ndarray, groups: np.ndarray) -> float:
    groups = np.asarray(groups)
    grand = X.mean(axis=0)
    uniq = np.unique(groups)
    n = len(groups)
    k = len(uniq)
    ss_between = 0.0
    ss_within = 0.0
    for g in uniq:
        Xi = X[groups == g]
        ci = Xi.mean(axis=0)
        ss_between += len(Xi) * np.sum((ci - grand) ** 2)
        ss_within += np.sum((Xi - ci) ** 2)
    ms_between = ss_between / (k - 1)
    ms_within = ss_within / (n - k)
    return float(ms_between / ms_within)


def permutation_g(dfsub: pd.DataFrame, mats: List[str], stratify_sector: bool, n_perm: int, seed: int) -> tuple[float, float]:
    rng = np.random.default_rng(seed)
    phases = dfsub["Phase"].to_numpy().copy()
    sectors = dfsub["Sector"].to_numpy()
    obs = np.vstack([
        dfsub.loc[phases == 2.0, mats].sum().to_numpy(),
        dfsub.loc[phases == 3.0, mats].sum().to_numpy(),
    ])
    G_obs = g_test(obs)
    sims = np.empty(n_perm)
    for i in range(n_perm):
        perm = phases.copy()
        if stratify_sector:
            for sec in np.unique(sectors):
                idx = np.where(sectors == sec)[0]
                perm[idx] = rng.permutation(perm[idx])
        else:
            perm = rng.permutation(perm)
        tab = np.vstack([
            dfsub.loc[perm == 2.0, mats].sum().to_numpy(),
            dfsub.loc[perm == 3.0, mats].sum().to_numpy(),
        ])
        sims[i] = g_test(tab)
    p = (np.sum(sims >= G_obs) + 1) / (n_perm + 1)
    return float(G_obs), float(p)


def permutation_permanova(dfsub: pd.DataFrame, mats: List[str], stratify_sector: bool, n_perm: int, seed: int) -> tuple[float, float]:
    rng = np.random.default_rng(seed)
    X_counts = dfsub[mats].to_numpy(float)
    rowtot = X_counts.sum(axis=1, keepdims=True)
    X_prop = np.divide(X_counts, rowtot, out=np.zeros_like(X_counts), where=rowtot > 0)
    X = np.sqrt(X_prop)
    phases = dfsub["Phase"].to_numpy().copy()
    sectors = dfsub["Sector"].to_numpy()
    F_obs = permanova_F(X, phases)
    sims = np.empty(n_perm)
    for i in range(n_perm):
        perm = phases.copy()
        if stratify_sector:
            for sec in np.unique(sectors):
                idx = np.where(sectors == sec)[0]
                perm[idx] = rng.permutation(perm[idx])
        else:
            perm = rng.permutation(perm)
        sims[i] = permanova_F(X, perm)
    p = (np.sum(sims >= F_obs) + 1) / (n_perm + 1)
    return float(F_obs), float(p)


def summarise_distances(values: List[float], label: str) -> dict:
    arr = np.asarray(values, dtype=float)
    return {
        "Comparison": label,
        "N_pairs": int(arr.size),
        "Mean": float(np.mean(arr)) if arr.size else np.nan,
        "Median": float(np.median(arr)) if arr.size else np.nan,
        "SD": float(np.std(arr, ddof=1)) if arr.size > 1 else np.nan,
        "Min": float(np.min(arr)) if arr.size else np.nan,
        "Max": float(np.max(arr)) if arr.size else np.nan,
        "Q1": float(np.quantile(arr, 0.25)) if arr.size else np.nan,
        "Q3": float(np.quantile(arr, 0.75)) if arr.size else np.nan,
    }


def make_phase_grid(df: pd.DataFrame, value_col: str, phase: float) -> np.ndarray:
    rows_present = [r for r in PLOT_ROW_ORDER if r in set(df["Row"])]
    grid = np.full((len(rows_present), 6), np.nan)
    sub = df[df["Phase"] == phase].copy()
    sub = sub.groupby(["Row", "Column"], as_index=False)[value_col].mean()
    for _, row in sub.iterrows():
        if row["Row"] not in rows_present:
            continue
        r_idx = rows_present.index(row["Row"])
        c_idx = int(row["Column"]) - 1
        if 0 <= c_idx < 6:
            grid[r_idx, c_idx] = row[value_col]
    return grid


def linear_material_cmap(hex_color: str) -> LinearSegmentedColormap:
    return LinearSegmentedColormap.from_list("material_scale", ["#ffffff", hex_color])


def clean_axes(ax) -> None:
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)


def panel_label(ax, s: str) -> None:
    ax.text(-0.12, 1.03, s, transform=ax.transAxes, fontsize=10, fontweight="bold", va="bottom")


def plot_ordination(df: pd.DataFrame, materials: List[str], outdir: Path) -> pd.DataFrame:
    X = hellinger_transform(df, materials)
    pca = PCA(n_components=2)
    coords = pca.fit_transform(X)

    fig, ax = plt.subplots(figsize=(7.5, 6))
    for phase, marker in [(2.0, "o"), (3.0, "s")]:
        mask = df["Phase"] == phase
        ax.scatter(coords[mask, 0], coords[mask, 1], label=f"Phase {int(phase)}", marker=marker, alpha=0.85)
        cx = coords[mask, 0].mean()
        cy = coords[mask, 1].mean()
        ax.scatter([cx], [cy], marker="X", s=160, edgecolor="black", linewidth=0.8)

    ax.set_xlabel(f"PC1 ({pca.explained_variance_ratio_[0]*100:.1f}% variance)")
    ax.set_ylabel(f"PC2 ({pca.explained_variance_ratio_[1]*100:.1f}% variance)")
    ax.set_title("Phase 2 vs Phase 3 ordination (Hellinger-transformed composition)")
    ax.legend(frameon=False)
    fig.tight_layout()
    fig.savefig(outdir / "fig1_ordination_phase2_vs_phase3.png", dpi=300)
    plt.close(fig)

    ord_df = df[["Square", "Depth 10cm", "Phase", "Sector", "Row", "Column"]].copy()
    ord_df["PC1"] = coords[:, 0]
    ord_df["PC2"] = coords[:, 1]
    return ord_df


def plot_stacked_composition(df: pd.DataFrame, materials: List[str], color_map: Dict[str, str], outdir: Path) -> pd.DataFrame:
    pooled = pooled_phase_proportions(df, materials)
    labels = [DISPLAY_LABELS.get(m, m) for m in materials]

    fig, ax = plt.subplots(figsize=(8.5, 6))
    bottom = np.zeros(len(pooled.index))
    for mat, label in zip(materials, labels):
        vals = pooled[mat].to_numpy()
        ax.bar([f"Phase {int(p)}" for p in pooled.index], vals, bottom=bottom, label=label, color=color_map[mat])
        bottom += vals

    ax.set_ylabel("Proportion of pooled assemblage")
    ax.set_title("Pooled raw-material composition by phase")
    ax.legend(bbox_to_anchor=(1.02, 1), loc="upper left", frameon=False, fontsize=8)
    fig.tight_layout()
    fig.savefig(outdir / "fig2_stacked_composition_phase2_vs_phase3.png", dpi=300)
    plt.close(fig)

    pooled_out = pooled.T.reset_index().rename(columns={"index": "Raw material", 2.0: "Phase_2_proportion", 3.0: "Phase_3_proportion"})
    pooled_out["Phase_2_minus_Phase_3"] = pooled_out["Phase_2_proportion"] - pooled_out["Phase_3_proportion"]
    pooled_out["Display_label"] = pooled_out["Raw material"].map(lambda x: DISPLAY_LABELS.get(x, x))
    pooled_out["Hex_colour"] = pooled_out["Raw material"].map(color_map)
    pooled_out = pooled_out.sort_values("Raw material").reset_index(drop=True)
    return pooled_out


def plot_material_differences(df: pd.DataFrame, materials: List[str], color_map: Dict[str, str], outdir: Path) -> pd.DataFrame:
    pooled = pooled_phase_proportions(df, materials)
    diff = (pooled.loc[2.0] - pooled.loc[3.0]).sort_values(ascending=False)

    fig, ax = plt.subplots(figsize=(10, 5.5))
    ax.bar(range(len(diff)), diff.values, color=[color_map[m] for m in diff.index])
    ax.axhline(0, linewidth=1, color="black")
    ax.set_xticks(range(len(diff)))
    ax.set_xticklabels([DISPLAY_LABELS.get(m, m) for m in diff.index], rotation=60, ha="right")
    ax.set_ylabel("Phase 2 proportion − Phase 3 proportion")
    ax.set_title("Raw-material differences between Phase 2 and Phase 3")
    fig.tight_layout()
    fig.savefig(outdir / "fig3_material_difference_phase2_vs_phase3.png", dpi=300)
    plt.close(fig)

    diff_df = diff.reset_index()
    diff_df.columns = ["Raw material", "Phase_2_minus_Phase_3"]
    diff_df["Absolute_difference"] = diff_df["Phase_2_minus_Phase_3"].abs()
    diff_df["Display_label"] = diff_df["Raw material"].map(lambda x: DISPLAY_LABELS.get(x, x))
    diff_df["Hex_colour"] = diff_df["Raw material"].map(color_map)
    return diff_df


def plot_distance_distributions(df: pd.DataFrame, materials: List[str], outdir: Path) -> pd.DataFrame:
    within2, within3, between = prepare_distance_lists(df, materials)

    fig, ax = plt.subplots(figsize=(7.5, 5.5))
    ax.boxplot(
        [within2, within3, between],
        tick_labels=["Within Phase 2", "Within Phase 3", "Between phases"],
        patch_artist=False,
    )
    ax.set_ylabel("Hellinger distance")
    ax.set_title("Compositional distances within and between phases")
    fig.tight_layout()
    fig.savefig(outdir / "fig4_distance_distributions_phase2_vs_phase3.png", dpi=300)
    plt.close(fig)

    return pd.DataFrame([
        summarise_distances(within2, "Within Phase 2"),
        summarise_distances(within3, "Within Phase 3"),
        summarise_distances(between, "Between phases"),
    ])


def plot_grid_heatmaps(df: pd.DataFrame, materials: List[str], color_map: Dict[str, str], outdir: Path) -> pd.DataFrame:
    pooled = pooled_phase_proportions(df, materials)
    diff = (pooled.loc[2.0] - pooled.loc[3.0]).abs().sort_values(ascending=False)
    top_materials = diff.index[:3].tolist()

    fig, axes = plt.subplots(len(top_materials), 2, figsize=(8.1, 3.3 * len(top_materials)))
    if len(top_materials) == 1:
        axes = np.array([axes])

    rows_present = [r for r in PLOT_ROW_ORDER if r in set(df["Row"])]
    heatmap_rows = []

    for i, mat in enumerate(top_materials):
        temp = df.copy()
        temp["Grid_proportion"] = np.divide(temp[mat], temp["Total_artefacts"], out=np.zeros(len(temp), dtype=float), where=temp["Total_artefacts"] > 0)
        g2 = make_phase_grid(temp, "Grid_proportion", 2.0)
        g3 = make_phase_grid(temp, "Grid_proportion", 3.0)
        vmax = np.nanmax([g2, g3])
        if not np.isfinite(vmax) or vmax <= 0:
            vmax = 1e-6

        for phase, grid in [(2.0, g2), (3.0, g3)]:
            for ridx, row_code in enumerate(rows_present):
                for cidx in range(grid.shape[1]):
                    if np.isfinite(grid[ridx, cidx]):
                        heatmap_rows.append({
                            "Raw material": mat,
                            "Phase": int(phase),
                            "Row": row_code,
                            "Column": cidx + 1,
                            "Grid_proportion": float(grid[ridx, cidx]),
                            "Hex_colour": color_map[mat],
                        })

        mat_cmap = linear_material_cmap(color_map[mat])
        mat_cmap.set_bad(NO_DATA_COLOR)
        for j, (grid, phase) in enumerate([(g2, 2.0), (g3, 3.0)]):
            ax = axes[i, j]
            im = ax.imshow(grid, vmin=0, vmax=vmax, cmap=mat_cmap, interpolation="none", aspect="equal", origin="lower")
            ax.set_xticks(range(6), labels=[1, 2, 3, 4, 5, 6])
            ax.set_yticks(range(len(rows_present)), labels=rows_present)
            ax.set_title(f"{DISPLAY_LABELS.get(mat, mat)} — Phase {int(phase)}")
            ax.set_xlabel("Column")
            ax.set_ylabel("Row")
            for x in range(7):
                ax.axvline(x - 0.5, color="white", linewidth=0.8)
            for y in range(len(rows_present) + 1):
                ax.axhline(y - 0.5, color="white", linewidth=0.8)
            cbar = fig.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
            cbar.ax.set_ylabel("Proportion", rotation=90)

    fig.suptitle("Grid-level material proportions by phase", y=0.995)
    fig.tight_layout()
    fig.savefig(outdir / "fig5_grid_heatmaps_phase2_vs_phase3.png", dpi=300)
    plt.close(fig)

    return pd.DataFrame(heatmap_rows)


def plot_sector_ordination(df: pd.DataFrame, materials: List[str], outdir: Path) -> pd.DataFrame:
    X = hellinger_transform(df, materials)
    pca = PCA(n_components=2)
    coords = pca.fit_transform(X)

    plot_df = df.copy()
    plot_df["PC1"] = coords[:, 0]
    plot_df["PC2"] = coords[:, 1]

    orig_rc = {k: plt.rcParams.get(k) for k in ["font.size", "axes.labelsize", "xtick.labelsize", "ytick.labelsize", "legend.fontsize"]}
    plt.rcParams.update({"font.size": 8, "axes.labelsize": 8, "xtick.labelsize": 7, "ytick.labelsize": 7, "legend.fontsize": 6.5})

    fig, axes = plt.subplots(1, 2, figsize=(10, 4.8), sharex=True, sharey=True)
    phase_specs = [(2.0, "o", "Phase 2"), (3.0, "s", "Phase 3")]
    centroid_rows = []

    for ax, sector in zip(axes, ["back", "front"]):
        sub = plot_df[plot_df["Sector"] == sector]
        for phase, marker, label in phase_specs:
            ss = sub[sub["Phase"] == phase]
            ax.scatter(ss["PC1"], ss["PC2"], s=36, marker=marker, alpha=0.85, label=label)
            if len(ss) > 0:
                cx = ss["PC1"].mean()
                cy = ss["PC2"].mean()
                ax.scatter([cx], [cy], marker="X", s=110, edgecolor="black", linewidth=0.7, zorder=5)
                centroid_rows.append({"Sector": sector, "Phase": int(phase), "PC1_centroid": float(cx), "PC2_centroid": float(cy), "N_units": int(len(ss))})

        ax.set_title(f"{sector.capitalize()} sector")
        ax.set_xlabel(f"PC1 ({pca.explained_variance_ratio_[0]*100:.1f}% variance)")
        ax.set_ylabel(f"PC2 ({pca.explained_variance_ratio_[1]*100:.1f}% variance)")
        clean_axes(ax)

    handles, labels = axes[0].get_legend_handles_labels()
    fig.legend(handles, labels, loc="upper center", bbox_to_anchor=(0.5, 0.98), ncol=2, frameon=False)
    fig.tight_layout(rect=(0, 0, 1, 0.90))
    fig.savefig(outdir / "fig6_sector_ordination_phase2_vs_phase3.png", dpi=300, bbox_inches="tight")
    plt.close(fig)
    plt.rcParams.update(orig_rc)

    return pd.DataFrame(centroid_rows)


def plot_final_composite(df: pd.DataFrame, materials: List[str], color_map: Dict[str, str], outdir: Path) -> None:
    pooled = pooled_phase_proportions(df, materials)

    top_materials = pooled.mean(axis=0).sort_values(ascending=False).head(10).index.tolist()
    pooled_simplified = pooled[top_materials].copy()
    pooled_simplified["Other"] = 1 - pooled_simplified.sum(axis=1)

    diff_full = pooled.loc[2.0] - pooled.loc[3.0]
    diff_sorted = diff_full.sort_values()
    diff_simplified = pd.concat([diff_sorted.head(6), diff_sorted.tail(6)])

    pooled_labels = [DISPLAY_LABELS.get(x, x).replace(" ", "\n", 1) if x in {"Gerowie Tuff", "Oenpelli Dolerite", "Green Weathered Volcanic"} else DISPLAY_LABELS.get(x, x) for x in pooled_simplified.columns]
    diff_labels = [ABBR_LABELS.get(x, x) for x in diff_simplified.index]

    X = hellinger_transform(df, materials)
    pca = PCA(n_components=2)
    coords = pca.fit_transform(X)
    phases = df["Phase"].to_numpy()

    within2, within3, between = prepare_distance_lists(df, materials)

    plt.rcParams.update({
        "font.size": 8,
        "axes.labelsize": 8,
        "xtick.labelsize": 7,
        "ytick.labelsize": 7,
        "legend.fontsize": 6.5,
        "pdf.fonttype": 42,
        "ps.fonttype": 42,
    })

    fig = plt.figure(figsize=(8.4, 10.4))
    outer = GridSpec(3, 2, figure=fig, width_ratios=[1.00, 1.08], height_ratios=[1.05, 1.00, 0.92], wspace=0.28, hspace=0.42)

    sub_a = GridSpecFromSubplotSpec(1, 2, subplot_spec=outer[0, 0], width_ratios=[0.72, 0.28], wspace=0.02)
    ax_a = fig.add_subplot(sub_a[0, 0])
    ax_a_leg = fig.add_subplot(sub_a[0, 1])

    sub_b = GridSpecFromSubplotSpec(1, 2, subplot_spec=outer[1, 0], width_ratios=[0.72, 0.28], wspace=0.02)
    ax_b = fig.add_subplot(sub_b[0, 0])
    ax_b_leg = fig.add_subplot(sub_b[0, 1])
    ax_c = fig.add_subplot(outer[0:2, 1])
    ax_d = fig.add_subplot(outer[2, :])

    for phase, marker, label in [(2.0, "o", "Phase 2"), (3.0, "s", "Phase 3")]:
        mask = phases == phase
        ax_c.scatter(coords[mask, 0], coords[mask, 1], s=18, marker=marker, alpha=0.85, label=label)
        cx = coords[mask, 0].mean()
        cy = coords[mask, 1].mean()
        ax_c.scatter([cx], [cy], marker="X", s=80, edgecolor="black", linewidth=0.7)

    ax_c.set_xlabel(f"PC1 ({pca.explained_variance_ratio_[0]*100:.1f}% variance)")
    ax_c.set_ylabel(f"PC2 ({pca.explained_variance_ratio_[1]*100:.1f}% variance)")
    ax_c.legend(frameon=False, loc="upper right", ncol=1)
    clean_axes(ax_c)
    panel_label(ax_c, "c")

    bottom = np.zeros(2)
    handles = []
    for m in pooled_simplified.columns:
        vals = pooled_simplified.loc[[2.0, 3.0], m].to_numpy()
        bars = ax_a.bar([0, 1], vals, bottom=bottom, width=0.58, linewidth=0, color=color_map[m])
        bottom += vals
        handles.append(bars[0])

    ax_a.set_xticks([0, 1])
    ax_a.set_xticklabels(["Phase 2", "Phase 3"])
    ax_a.set_ylabel("Proportion")
    ax_a.set_ylim(0, 1.0)
    clean_axes(ax_a)
    panel_label(ax_a, "a")

    ax_a_leg.axis("off")
    ax_a_leg.legend(handles, pooled_labels, frameon=False, loc="center left", handlelength=0.9, handletextpad=0.4, labelspacing=0.22, borderpad=0.0, columnspacing=0.6, ncol=1, fontsize=5.8)

    xb = np.arange(len(diff_simplified))
    diff_colors = [color_map.get(m, OTHER_COLOR) for m in diff_simplified.index]
    bars_b = ax_b.bar(xb, diff_simplified.values, width=0.76, linewidth=0, color=diff_colors)
    ax_b.axhline(0, color="black", linewidth=0.8)
    ax_b.set_xticks([])
    ax_b.set_xlim(-0.5, len(diff_simplified) - 0.5)
    ax_b.set_ylabel("P2 − P3 proportion")
    clean_axes(ax_b)
    panel_label(ax_b, "b")

    ax_b_leg.axis("off")
    ax_b_leg.legend(
        bars_b,
        [DISPLAY_LABELS.get(m, m) for m in diff_simplified.index],
        frameon=False,
        loc="center left",
        handlelength=0.9,
        handletextpad=0.4,
        labelspacing=0.28,
        borderpad=0.0,
        columnspacing=0.6,
        ncol=1,
        fontsize=5.8,
    )

    ax_d.boxplot(
        [within2, within3, between],
        tick_labels=["Within Phase 2", "Within Phase 3", "Between phases"],
        widths=0.55,
        showfliers=True,
        flierprops=dict(marker="o", markersize=3, markerfacecolor="none", markeredgecolor="black", markeredgewidth=0.28, alpha=0.8),
    )
    ax_d.set_ylabel("Hellinger distance")
    clean_axes(ax_d)
    panel_label(ax_d, "d")

    fig.subplots_adjust(left=0.07, right=0.98, top=0.97, bottom=0.07)
    fig.savefig(outdir / "fig7_composite_phase2_vs_phase3_final.png", dpi=400)
    fig.savefig(outdir / "fig7_composite_phase2_vs_phase3_final.pdf")
    plt.close(fig)


def write_results(df: pd.DataFrame, materials: List[str], color_map: Dict[str, str], outdir: Path, n_perm: int) -> None:
    results_dir = outdir / "phase2_vs_phase3_tables"
    results_dir.mkdir(parents=True, exist_ok=True)

    G_all, pG_all = permutation_g(df, materials, stratify_sector=True, n_perm=n_perm, seed=42)
    F_all, pF_all = permutation_permanova(df, materials, stratify_sector=True, n_perm=n_perm, seed=123)

    overall_df = pd.DataFrame([{
        "Comparison": "Phase 2 vs Phase 3",
        "N_units_total": len(df),
        "N_phase2": int((df["Phase"] == 2.0).sum()),
        "N_phase3": int((df["Phase"] == 3.0).sum()),
        "Materials_tested": len(materials),
        "G_stat_stratified_by_sector": G_all,
        "p_G": pG_all,
        "PERMANOVA_F_stratified_by_sector": F_all,
        "p_PERMANOVA": pF_all,
    }])

    sector_rows = []
    for sec, seed1, seed2 in [("back", 7, 11), ("front", 13, 17)]:
        sub = df[df["Sector"] == sec].copy()
        G, pG = permutation_g(sub, materials, stratify_sector=False, n_perm=n_perm, seed=seed1)
        F, pF = permutation_permanova(sub.assign(Sector=sec), materials, stratify_sector=False, n_perm=n_perm, seed=seed2)
        sector_rows.append({
            "Sector": sec,
            "N_units": len(sub),
            "N_phase2": int((sub["Phase"] == 2.0).sum()),
            "N_phase3": int((sub["Phase"] == 3.0).sum()),
            "G_stat": G,
            "p_G": pG,
            "PERMANOVA_F": F,
            "p_PERMANOVA": pF,
        })
    sector_df = pd.DataFrame(sector_rows)

    ord_df = plot_ordination(df, materials, outdir)
    pooled_df = plot_stacked_composition(df, materials, color_map, outdir)
    diff_df = plot_material_differences(df, materials, color_map, outdir)
    distance_df = plot_distance_distributions(df, materials, outdir)
    heatmap_df = plot_grid_heatmaps(df, materials, color_map, outdir)
    sector_centroids_df = plot_sector_ordination(df, materials, outdir)
    plot_final_composite(df, materials, color_map, outdir)

    phase_unit_counts = (
        df.groupby(["Phase", "Sector", "Row", "Column"], as_index=False)
          .agg(Total_artefacts=("Total_artefacts", "sum"))
          .sort_values(["Phase", "Row", "Column"])
    )

    palette_df = pd.DataFrame({
        "Raw material": list(color_map.keys()),
        "Hex_colour": list(color_map.values()),
    })

    overall_df.to_csv(results_dir / "phase2_vs_phase3_overall_tests.csv", index=False)
    sector_df.to_csv(results_dir / "phase2_vs_phase3_sector_tests.csv", index=False)
    pooled_df.to_csv(results_dir / "phase2_vs_phase3_pooled_composition_table.csv", index=False)
    diff_df.to_csv(results_dir / "phase2_vs_phase3_material_difference_table.csv", index=False)
    distance_df.to_csv(results_dir / "phase2_vs_phase3_distance_summary_table.csv", index=False)
    ord_df.to_csv(results_dir / "phase2_vs_phase3_ordination_coordinates.csv", index=False)
    sector_centroids_df.to_csv(results_dir / "phase2_vs_phase3_sector_ordination_centroids.csv", index=False)
    heatmap_df.to_csv(results_dir / "phase2_vs_phase3_grid_heatmap_values.csv", index=False)
    phase_unit_counts.to_csv(results_dir / "phase2_vs_phase3_square_depth_unit_totals.csv", index=False)
    palette_df.to_csv(results_dir / "phase2_vs_phase3_colour_mapping.csv", index=False)

    report = dedent(f"""
    Phase 2 vs Phase 3 compositional equivalence analysis: figure and SI table package

    Dataset
    - Comparison: Phase 2 vs Phase 3
    - Square-depth units analysed: {len(df)}
    - Phase 2 units: {int((df['Phase'] == 2.0).sum())}
    - Phase 3 units: {int((df['Phase'] == 3.0).sum())}
    - Raw-material categories tested: {len(materials)}
    - Permutations per test: {n_perm}

    Formal statistical tests
    1. Permutation G-test on pooled raw-material composition, stratified by sector
       - G = {G_all:.3f}
       - p = {pG_all:.6f}

    2. PERMANOVA on Hellinger-transformed square-depth compositions, stratified by sector
       - F = {F_all:.3f}
       - p = {pF_all:.6f}

    Sector-specific tests
    - Back sector: G = {sector_df.loc[sector_df['Sector']=='back', 'G_stat'].iloc[0]:.3f}, p = {sector_df.loc[sector_df['Sector']=='back', 'p_G'].iloc[0]:.6f}; F = {sector_df.loc[sector_df['Sector']=='back', 'PERMANOVA_F'].iloc[0]:.3f}, p = {sector_df.loc[sector_df['Sector']=='back', 'p_PERMANOVA'].iloc[0]:.6f}
    - Front sector: G = {sector_df.loc[sector_df['Sector']=='front', 'G_stat'].iloc[0]:.3f}, p = {sector_df.loc[sector_df['Sector']=='front', 'p_G'].iloc[0]:.6f}; F = {sector_df.loc[sector_df['Sector']=='front', 'PERMANOVA_F'].iloc[0]:.3f}, p = {sector_df.loc[sector_df['Sector']=='front', 'p_PERMANOVA'].iloc[0]:.6f}

    Files written for SI use
    - phase2_vs_phase3_overall_tests.csv
    - phase2_vs_phase3_sector_tests.csv
    - phase2_vs_phase3_pooled_composition_table.csv
    - phase2_vs_phase3_material_difference_table.csv
    - phase2_vs_phase3_distance_summary_table.csv
    - phase2_vs_phase3_ordination_coordinates.csv
    - phase2_vs_phase3_sector_ordination_centroids.csv
    - phase2_vs_phase3_grid_heatmap_values.csv
    - phase2_vs_phase3_square_depth_unit_totals.csv
    - phase2_vs_phase3_colour_mapping.csv

    Figure updates applied
    - Fig. 5 grid layout now uses the actual trench footprint, with B at the top and E at the bottom.
    - No-data cells are shown in light grey ({NO_DATA_COLOR}).
    - Oenpelli Dolerite remains a darker grey ({BASE_MATERIAL_COLORS['Oenpelli Dolerite']}) to avoid confusion with no-data cells.
    - Composition and material-coded panels now use the standard manuscript palette.
    """).strip() + "\n"

    (results_dir / "phase2_vs_phase3_summary_report.txt").write_text(report, encoding="utf-8")


def main() -> None:
    args = parse_args()
    outdir = Path(args.output_dir)
    outdir.mkdir(parents=True, exist_ok=True)

    print(f"Loading input: {args.input}")
    df, materials = load_and_prepare(args.input)
    print(f"Loaded {len(df)} Phase 2/3 square-depth units")
    print(f"Materials used: {', '.join(materials)}")

    color_map = get_material_color_map(materials)
    write_results(df, materials, color_map, outdir, args.n_perm)

    print(f"Saved figures and tables to: {outdir.resolve()}")


if __name__ == "__main__":
    main()
